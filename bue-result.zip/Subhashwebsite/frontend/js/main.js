// Mobile Menu Toggle
document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.querySelector('.menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            navLinks.classList.toggle('active');
            menuToggle.innerHTML = navLinks.classList.contains('active') 
                ? '<i class="fas fa-times"></i>' 
                : '<i class="fas fa-bars"></i>';
        });
    }
    
    // Close menu when clicking outside
    document.addEventListener('click', function(event) {
        if (!event.target.closest('nav') && navLinks.classList.contains('active')) {
            navLinks.classList.remove('active');
            menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
        }
    });
    
    // Auto-scrolling notices (optional)
    const noticeBoard = document.querySelector('.notice-board');
    if (noticeBoard) {
        let scrollPos = 0;
        const scrollNotice = () => {
            if (scrollPos >= noticeBoard.scrollHeight / 2) {
                scrollPos = 0;
            } else {
                scrollPos += 1;
            }
            noticeBoard.scrollTop = scrollPos;
        };
        
        // Uncomment for auto-scroll
        // setInterval(scrollNotice, 50);
    }
    
    // Check if user is logged in (from localStorage)
    checkLoginStatus();
});

// Check Login Status
function checkLoginStatus() {
    const user = localStorage.getItem('studentUser');
    const loginBtn = document.querySelector('.btn-login');
    
    if (user && loginBtn) {
        const userData = JSON.parse(user);
        loginBtn.innerHTML = `<i class="fas fa-user"></i> ${userData.name.split(' ')[0]}`;
        loginBtn.href = 'pages/dashboard.html';
    }
}

// Simple Alert for Coming Soon Features
function showAlert(message) {
    alert(message || "This feature will be available soon!");
}