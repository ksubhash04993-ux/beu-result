import os
import uuid
from werkzeug.utils import secure_filename
from flask import current_app
from PIL import Image
import mimetypes

def allowed_file(filename, allowed_extensions=None):
    """Check if file extension is allowed"""
    if allowed_extensions is None:
        allowed_extensions = current_app.config['ALLOWED_EXTENSIONS']
    
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in allowed_extensions

def get_file_extension(filename):
    """Get file extension from filename"""
    return filename.rsplit('.', 1)[1].lower() if '.' in filename else ''

def generate_unique_filename(filename):
    """Generate unique filename to avoid collisions"""
    ext = get_file_extension(filename)
    unique_id = uuid.uuid4().hex[:8]
    base_name = secure_filename(filename.rsplit('.', 1)[0])
    return f"{base_name}_{unique_id}.{ext}"

def save_uploaded_file(file, folder='notes'):
    """Save uploaded file to appropriate folder"""
    if not file or file.filename == '':
        return None
    
    if not allowed_file(file.filename):
        return None
    
    # Generate unique filename
    filename = generate_unique_filename(file.filename)
    
    # Create upload path
    upload_folder = os.path.join(
        current_app.config['UPLOAD_FOLDER'],
        folder
    )
    
    # Ensure folder exists
    os.makedirs(upload_folder, exist_ok=True)
    
    # Save file
    filepath = os.path.join(upload_folder, filename)
    file.save(filepath)
    
    # Return relative path for database
    return f"uploads/{folder}/{filename}"

def save_profile_picture(file, user_id):
    """Save and resize profile picture"""
    if not file or not allowed_file(file.filename, {'png', 'jpg', 'jpeg'}):
        return None
    
    # Generate filename
    ext = get_file_extension(file.filename)
    filename = f"profile_{user_id}.{ext}"
    
    # Create profile pics folder
    profile_folder = os.path.join(
        current_app.config['UPLOAD_FOLDER'],
        'profile_pics'
    )
    os.makedirs(profile_folder, exist_ok=True)
    
    # Save original
    original_path = os.path.join(profile_folder, filename)
    file.save(original_path)
    
    # Resize image to 200x200
    try:
        img = Image.open(original_path)
        img.thumbnail((200, 200))
        img.save(original_path, optimize=True, quality=85)
    except Exception as e:
        current_app.logger.error(f"Error resizing image: {e}")
    
    return f"uploads/profile_pics/{filename}"

def get_file_size(filepath):
    """Get file size in human readable format"""
    try:
        size_bytes = os.path.getsize(filepath)
        
        # Convert to appropriate unit
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size_bytes < 1024.0:
                return f"{size_bytes:.1f} {unit}"
            size_bytes /= 1024.0
        
        return f"{size_bytes:.1f} TB"
    except:
        return "Unknown"

def delete_file(filepath):
    """Delete file from server"""
    try:
        full_path = os.path.join(current_app.config['UPLOAD_FOLDER'], 
                                filepath.replace('uploads/', '', 1))
        if os.path.exists(full_path):
            os.remove(full_path)
            return True
    except Exception as e:
        current_app.logger.error(f"Error deleting file: {e}")
    
    return False

def get_mime_type(filename):
    """Get MIME type of file"""
    return mimetypes.guess_type(filename)[0] or 'application/octet-stream'