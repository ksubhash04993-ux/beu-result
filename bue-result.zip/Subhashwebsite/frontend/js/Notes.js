// Notes Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    const user = localStorage.getItem('studentUser');
    if (!user) {
        window.location.href = '../login.html';
        return;
    }
    
    const userData = JSON.parse(user);
    
    // Set user info
    document.getElementById('studentName').textContent = userData.name || 'Student';
    document.getElementById('studentRoll').textContent = `Roll No: ${userData.rollno || 'N/A'}`;
    
    // Set default filters based on user data
    if (userData.branch) {
        document.getElementById('branchFilter').value = userData.branch.toLowerCase();
    }
    if (userData.semester) {
        document.getElementById('semesterFilter').value = userData.semester;
    }
    
    // Time update
    function updateTime() {
        const now = new Date();
        const timeStr = now.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit',
            hour12: true 
        });
        document.getElementById('currentTime').textContent = timeStr;
    }
    updateTime();
    setInterval(updateTime, 60000);
    
    // Logout functionality
    document.getElementById('logoutBtn').addEventListener('click', function(e) {
        e.preventDefault();
        if (confirm('Are you sure you want to logout?')) {
            localStorage.removeItem('studentUser');
            window.location.href = '../login.html';
        }
    });
    
    // Load notes
    loadNotes();
    loadRecentDownloads();
});

// Sample notes data
const notesData = [
    {
        id: 1,
        subject: "Data Structures",
        code: "CSE301",
        title: "Complete DS Notes - All Units",
        description: "Complete notes covering Arrays, Linked Lists, Stacks, Queues, Trees, Graphs, and Sorting Algorithms.",
        branch: "cse",
        semester: "5",
        type: "ds",
        size: "4.2 MB",
        pages: 85,
        author: "Dr. R. Kumar",
        uploaded: "2024-04-15",
        downloads: 1245,
        featured: true
    },
    {
        id: 2,
        subject: "Database Management",
        code: "CSE302",
        title: "DBMS Unit 1-3 Notes",
        description: "Detailed notes on ER Diagrams, Relational Model, Normalization, and SQL queries.",
        branch: "cse",
        semester: "5",
        type: "dbms",
        size: "3.8 MB",
        pages: 72,
        author: "Dr. S. Singh",
        uploaded: "2024-04-10",
        downloads: 987,
        featured: false
    },
    {
        id: 3,
        subject: "Operating Systems",
        code: "CSE303",
        title: "OS Process & Memory Management",
        description: "Notes on Process Scheduling, Deadlocks, Memory Management, and Virtual Memory.",
        branch: "cse",
        semester: "5",
        type: "os",
        size: "5.1 MB",
        pages: 94,
        author: "Prof. A. Sharma",
        uploaded: "2024-04-05",
        downloads: 856,
        featured: true
    },
    {
        id: 4,
        subject: "Computer Networks",
        code: "CSE304",
        title: "CN Complete Reference",
        description: "Complete networking notes covering OSI Model, TCP/IP, Routing Protocols, and Network Security.",
        branch: "cse",
        semester: "5",
        type: "cn",
        size: "6.3 MB",
        pages: 112,
        author: "Dr. P. Verma",
        uploaded: "2024-03-28",
        downloads: 743,
        featured: false
    },
    {
        id: 5,
        subject: "Theory of Computation",
        code: "CSE305",
        title: "TOC Automata & Languages",
        description: "Notes on Finite Automata, Regular Expressions, Context-Free Grammars, and Turing Machines.",
        branch: "cse",
        semester: "5",
        type: "toc",
        size: "3.5 MB",
        pages: 68,
        author: "Prof. M. Gupta",
        uploaded: "2024-03-20",
        downloads: 612,
        featured: false
    },
    {
        id: 6,
        subject: "Discrete Mathematics",
        code: "MATH301",
        title: "DM Complete Syllabus",
        description: "Mathematical logic, Sets, Relations, Functions, Combinatorics, and Graph Theory.",
        branch: "cse",
        semester: "5",
        type: "math",
        size: "4.7 MB",
        pages: 89,
        author: "Dr. N. Roy",
        uploaded: "2024-03-15",
        downloads: 534,
        featured: false
    }
];

function loadNotes() {
    const branch = document.getElementById('branchFilter').value;
    const semester = document.getElementById('semesterFilter').value;
    const subject = document.getElementById('subjectFilter').value;
    
    const filteredNotes = notesData.filter(note => {
        return (branch === 'all' || note.branch === branch) &&
               (semester === 'all' || note.semester === semester) &&
               (subject === 'all' || note.type === subject);
    });
    
    const notesGrid = document.getElementById('notesGrid');
    notesGrid.innerHTML = '';
    
    document.getElementById('notesCount').textContent = `${filteredNotes.length} notes found`;
    
    filteredNotes.forEach(note => {
        const noteCard = document.createElement('div');
        noteCard.className = `note-card ${note.featured ? 'featured' : ''}`;
        noteCard.innerHTML = `
            <div class="note-header">
                <div class="note-subject">${note.subject}</div>
                <div class="note-code">${note.code}</div>
                <div class="note-favorite" onclick="toggleFavorite(${note.id})">
                    <i class="far fa-heart"></i>
                </div>
            </div>
            <div class="note-body">
                <h4 class="note-title">${note.title}</h4>
                <div class="note-meta">
                    <span class="meta-item">
                        <i class="fas fa-user"></i> ${note.author}
                    </span>
                    <span class="meta-item">
                        <i class="fas fa-calendar"></i> ${formatDate(note.uploaded)}
                    </span>
                    <span class="meta-item">
                        <i class="fas fa-download"></i> ${note.downloads}
                    </span>
                </div>
                <p class="note-description">${note.description}</p>
                <div class="note-footer">
                    <span class="note-size">
                        <i class="fas fa-file-pdf"></i> ${note.size} • ${note.pages} pages
                    </span>
                    <div class="note-actions">
                        <button class="btn-preview" onclick="previewNote(${note.id})">
                            <i class="fas fa-eye"></i> Preview
                        </button>
                        <button class="btn-download" onclick="downloadNote(${note.id})">
                            <i class="fas fa-download"></i> Download
                        </button>
                    </div>
                </div>
            </div>
        `;
        notesGrid.appendChild(noteCard);
    });
}

function filterNotes() {
    loadNotes();
}

function changeView(viewType) {
    const notesGrid = document.getElementById('notesGrid');
    const viewBtns = document.querySelectorAll('.view-btn');
    
    viewBtns.forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    if (viewType === 'list') {
        notesGrid.classList.add('list-view');
        notesGrid.querySelectorAll('.note-card').forEach(card => {
            card.classList.add('list-view');
        });
    } else {
        notesGrid.classList.remove('list-view');
        notesGrid.querySelectorAll('.note-card').forEach(card => {
            card.classList.remove('list-view');
        });
    }
}

function toggleFavorite(noteId) {
    const heartIcon = event.target.closest('.note-favorite').querySelector('i');
    if (heartIcon.classList.contains('far')) {
        heartIcon.classList.remove('far');
        heartIcon.classList.add('fas');
        heartIcon.style.color = '#ff4081';
        alert('Added to favorites!');
    } else {
        heartIcon.classList.remove('fas');
        heartIcon.classList.add('far');
        heartIcon.style.color = '';
        alert('Removed from favorites!');
    }
}

function previewNote(noteId) {
    const note = notesData.find(n => n.id === noteId);
    if (!note) return;
    
    document.getElementById('modalNoteTitle').textContent = note.title;
    
    const previewHTML = `
        <div class="note-preview">
            <div class="preview-icon">
                <i class="fas fa-file-pdf"></i>
            </div>
            <h2 class="preview-title">${note.title}</h2>
            <h3 class="preview-subject">${note.subject} (${note.code})</h3>
            
            <div class="preview-meta">
                <div class="preview-meta-item">
                    <i class="fas fa-user"></i>
                    <span>Author</span>
                    <p>${note.author}</p>
                </div>
                <div class="preview-meta-item">
                    <i class="fas fa-calendar"></i>
                    <span>Upload Date</span>
                    <p>${formatDate(note.uploaded)}</p>
                </div>
                <div class="preview-meta-item">
                    <i class="fas fa-download"></i>
                    <span>Downloads</span>
                    <p>${note.downloads}</p>
                </div>
                <div class="preview-meta-item">
                    <i class="fas fa-file"></i>
                    <span>File Size</span>
                    <p>${note.size}</p>
                </div>
            </div>
            
            <div class="preview-description">
                <h4>Description</h4>
                <p>${note.description}</p>
                <p><strong>Pages:</strong> ${note.pages} pages</p>
                <p><strong>Branch:</strong> ${note.branch.toUpperCase()}</p>
                <p><strong>Semester:</strong> ${note.semester}</p>
            </div>
        </div>
    `;
    
    document.getElementById('notePreview').innerHTML = previewHTML;
    document.getElementById('notesModal').classList.add('active');
    
    // Store current note ID for download
    document.getElementById('notesModal').setAttribute('data-note-id', noteId);
}

function closeModal() {
    document.getElementById('notesModal').classList.remove('active');
}

function downloadNote(noteId = null) {
    if (!noteId) {
        noteId = document.getElementById('notesModal').getAttribute('data-note-id');
    }
    
    const note = notesData.find(n => n.id === Number(noteId));
    if (!note) return;
    
    // Update download count
    note.downloads++;
    
    // Add to recent downloads
    addToRecentDownloads(note);
    
    // Show success message
    alert(`Downloading: ${note.title}\n\nFile will be saved as "${note.subject.replace(/\s+/g, '_')}_Notes.pdf"`);
    
    // Simulate download
    const downloadText = `
BEU Study Notes
===============

Title: ${note.title}
Subject: ${note.subject} (${note.code})
Author: ${note.author}
Upload Date: ${formatDate(note.uploaded)}
File Size: ${note.size}
Pages: ${note.pages}

Description:
${note.description}

Branch: ${note.branch.toUpperCase()}
Semester: ${note.semester}

---
This is a sample file. In actual implementation,
this would be a PDF document containing the complete notes.
    `;
    
    const blob = new Blob([downloadText], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${note.subject.replace(/\s+/g, '_')}_Notes.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    // Close modal if open
    closeModal();
    
    // Reload notes to update download count
    setTimeout(() => loadNotes(), 100);
}

function addToRecentDownloads(note) {
    const recentDownloads = JSON.parse(localStorage.getItem('recentDownloads') || '[]');
    
    const downloadRecord = {
        noteId: note.id,
        title: note.title,
        subject: note.subject,
        downloadedAt: new Date().toISOString()
    };
    
    // Add to beginning
    recentDownloads.unshift(downloadRecord);
    
    // Keep only last 5
    if (recentDownloads.length > 5) {
        recentDownloads.pop();
    }
    
    localStorage.setItem('recentDownloads', JSON.stringify(recentDownloads));
    loadRecentDownloads();
}

function loadRecentDownloads() {
    const recentDownloads = JSON.parse(localStorage.getItem('recentDownloads') || '[]');
    const recentList = document.getElementById('recentDownloads');
    
    if (recentDownloads.length === 0) {
        recentList.innerHTML = `
            <div class="recent-item">
                <div class="recent-info">
                    <h5>No recent downloads</h5>
                    <p>Download notes to see them here</p>
                </div>
            </div>
        `;
        return;
    }
    
    recentList.innerHTML = '';
    
    recentDownloads.forEach(download => {
        const timeAgo = getTimeAgo(download.downloadedAt);
        const note = notesData.find(n => n.id === download.noteId);
        
        const recentItem = document.createElement('div');
        recentItem.className = 'recent-item';
        recentItem.innerHTML = `
            <div class="recent-info">
                <h5>${download.title}</h5>
                <p>
                    <span><i class="fas fa-book"></i> ${download.subject}</span>
                    <span class="recent-time"><i class="fas fa-clock"></i> ${timeAgo}</span>
                </p>
            </div>
            <button class="btn-download" onclick="downloadNote(${download.noteId})">
                <i class="fas fa-redo"></i> Download Again
            </button>
        `;
        recentList.appendChild(recentItem);
    });
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function getTimeAgo(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 60) {
        return `${diffMins} minute${diffMins !== 1 ? 's' : ''} ago`;
    } else if (diffHours < 24) {
        return `${diffHours} hour${diffHours !== 1 ? 's' : ''} ago`;
    } else if (diffDays < 7) {
        return `${diffDays} day${diffDays !== 1 ? 's' : ''} ago`;
    } else {
        return formatDate(dateString);
    }
}