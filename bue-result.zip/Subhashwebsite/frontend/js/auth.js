// Auth JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Password toggle
    const togglePassword = document.getElementById('togglePassword');
    if (togglePassword) {
        togglePassword.addEventListener('click', function() {
            const passwordInput = document.getElementById('password');
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.classList.toggle('fa-eye');
            this.classList.toggle('fa-eye-slash');
        });
    }
    
    // Login Form Submission
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const rollno = document.getElementById('rollno').value;
            const password = document.getElementById('password').value;
            
            // Simple validation
            if (!rollno || !password) {
                alert('Please fill all fields');
                return;
            }
            
            // Check if user exists in localStorage
            const users = JSON.parse(localStorage.getItem('students')) || [];
            const user = users.find(u => u.rollno === rollno && u.password === password);
            
            if (user || (rollno === 'test' && password === '1234')) {
                // Create user session
                const sessionUser = user || {
                    name: 'Test Student',
                    rollno: 'BEU2024001',
                    branch: 'CSE',
                    semester: '5'
                };
                
                localStorage.setItem('studentUser', JSON.stringify(sessionUser));
                alert('Login successful! Redirecting to dashboard...');
                window.location.href = '../pages/dashboard.html';
            } else {
                alert('Invalid credentials. Use rollno: test, password: 1234 for demo');
            }
        });
    }
    
    // Register Form Submission
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const name = document.getElementById('fullName').value;
            const rollno = document.getElementById('rollno').value;
            const email = document.getElementById('email').value;
            const branch = document.getElementById('branch').value;
            const semester = document.getElementById('semester').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            
            // Validation
            if (!name || !rollno || !email || !branch || !semester || !password) {
                alert('Please fill all fields');
                return;
            }
            
            if (password !== confirmPassword) {
                alert('Passwords do not match');
                return;
            }
            
            if (password.length < 8) {
                alert('Password must be at least 8 characters');
                return;
            }
            
            // Get existing users
            const users = JSON.parse(localStorage.getItem('students')) || [];
            
            // Check if user already exists
            if (users.find(u => u.rollno === rollno)) {
                alert('User with this roll number already exists');
                return;
            }
            
            // Add new user
            const newUser = {
                name,
                rollno,
                email,
                branch,
                semester,
                password,
                registeredAt: new Date().toISOString()
            };
            
            users.push(newUser);
            localStorage.setItem('students', JSON.stringify(users));
            
            // Auto login
            localStorage.setItem('studentUser', JSON.stringify(newUser));
            
            alert('Registration successful! Redirecting to dashboard...');
            window.location.href = '../pages/dashboard.html';
        });
    }
});