// Notices Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    const user = localStorage.getItem('studentUser');
    if (!user) {
        window.location.href = '../login.html';
        return;
    }
    
    const userData = JSON.parse(user);
    
    // Set user info
    document.getElementById('studentName').textContent = userData.name || 'Student';
    document.getElementById('studentRoll').textContent = `Roll No: ${userData.rollno || 'N/A'}`;
    
    // Time update
    function updateTime() {
        const now = new Date();
        const timeStr = now.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit',
            hour12: true 
        });
        document.getElementById('currentTime').textContent = timeStr;
    }
    updateTime();
    setInterval(updateTime, 60000);
    
    // Logout functionality
    document.getElementById('logoutBtn').addEventListener('click', function(e) {
        e.preventDefault();
        if (confirm('Are you sure you want to logout?')) {
            localStorage.removeItem('studentUser');
            window.location.href = '../login.html';
        }
    });
    
    // Load notices
    loadNotices('all');
    updateUnreadCount();
});

// Sample notices data
const noticesData = [
    {
        id: 1,
        title: "BEU Odd Semester Result 2024 Declared",
        content: "The results for BEU Odd Semester examinations 2024 have been declared. Students can check their results using their roll number on the university portal. For any discrepancies, contact the examination cell within 15 days.",
        category: "exam",
        date: "2024-05-15",
        author: "Exam Controller",
        priority: "urgent",
        read: false,
        attachments: [
            { name: "Result Notification.pdf", size: "1.2 MB" },
            { name: "Grace Marks List.pdf", size: "0.8 MB" }
        ]
    },
    {
        id: 2,
        title: "Summer Vacation Schedule 2024",
        content: "The college will remain closed for summer vacation from 1st June 2024 to 15th July 2024. All administrative offices will remain closed during this period. The new academic session will commence from 16th July 2024.",
        category: "academic",
        date: "2024-05-10",
        author: "Registrar Office",
        priority: "normal",
        read: true,
        attachments: [
            { name: "Vacation Schedule.pdf", size: "0.9 MB" }
        ]
    },
    {
        id: 3,
        title: "Last Date for Exam Form Submission",
        content: "The last date for submission of examination forms for Even Semester 2024 is 30th May 2024. Late submission will not be accepted under any circumstances. Submit your forms along with required fees at the examination cell.",
        category: "exam",
        date: "2024-05-05",
        author: "Exam Department",
        priority: "urgent",
        read: false,
        attachments: [
            { name: "Exam Form Guidelines.pdf", size: "1.5 MB" },
            { name: "Fee Structure.pdf", size: "0.7 MB" }
        ]
    },
    {
        id: 4,
        title: "Workshop on Artificial Intelligence & Machine Learning",
        content: "The Department of Computer Science is organizing a 3-day workshop on AI & ML from 25th to 27th May 2024. Interested students can register by 20th May. Limited seats available. Certificate will be provided to all participants.",
        category: "event",
        date: "2024-05-01",
        author: "CSE Department",
        priority: "normal",
        read: true,
        attachments: [
            { name: "Workshop Brochure.pdf", size: "2.1 MB" },
            { name: "Registration Form.docx", size: "0.5 MB" }
        ]
    },
    {
        id: 5,
        title: "Library Book Return Notice",
        content: "All students are requested to return borrowed library books before 25th May 2024. Late returns will incur a fine of ₹10 per day per book. Books needed for summer vacation can be issued on 28th May.",
        category: "academic",
        date: "2024-04-28",
        author: "Library Incharge",
        priority: "normal",
        read: false,
        attachments: [
            { name: "Book Return Notice.pdf", size: "0.6 MB" }
        ]
    },
    {
        id: 6,
        title: "Sports Week 2024 - Registration Open",
        content: "Annual Sports Week will be conducted from 10th to 15th June 2024. Students can register for various sports events including cricket, football, basketball, athletics and indoor games. Registration closes on 5th June.",
        category: "event",
        date: "2024-04-25",
        author: "Sports Committee",
        priority: "normal",
        read: true,
        attachments: [
            { name: "Sports Week Schedule.pdf", size: "1.8 MB" },
            { name: "Registration Details.pdf", size: "1.1 MB" }
        ]
    },
    {
        id: 7,
        title: "Industry Visit - Tech Mahindra Campus",
        content: "An industrial visit to Tech Mahindra campus, Patna is scheduled for 30th May 2024 for final year CSE and IT students. Interested students should submit their consent forms by 25th May. Transportation will be provided.",
        category: "academic",
        date: "2024-04-20",
        author: "Training & Placement Cell",
        priority: "normal",
        read: true,
        attachments: [
            { name: "Visit Schedule.pdf", size: "1.3 MB" },
            { name: "Consent Form.pdf", size: "0.4 MB" }
        ]
    },
    {
        id: 8,
        title: "Fee Payment Deadline Extended",
        content: "Due to technical issues in the online payment portal, the last date for fee payment has been extended to 5th June 2024. Students are advised to complete their payments before the deadline to avoid late fees.",
        category: "academic",
        date: "2024-04-15",
        author: "Accounts Department",
        priority: "urgent",
        read: true,
        attachments: [
            { name: "Fee Extension Notice.pdf", size: "0.9 MB" }
        ]
    }
];

function loadNotices(category) {
    const filteredNotices = category === 'all' 
        ? noticesData 
        : noticesData.filter(notice => notice.category === category);
    
    const noticesList = document.getElementById('noticesList');
    noticesList.innerHTML = '';
    
    // Update active filter button
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    event?.target.classList.add('active');
    
    filteredNotices.forEach(notice => {
        const noticeItem = document.createElement('div');
        noticeItem.className = `notice-item ${notice.read ? '' : 'unread'} ${notice.priority === 'urgent' ? 'urgent' : ''}`;
        noticeItem.onclick = () => viewNotice(notice.id);
        
        const badgeClass = notice.category === 'exam' ? 'exam' :
                         notice.category === 'academic' ? 'academic' :
                         notice.category === 'event' ? 'event' : 'urgent';
        
        const badgeText = notice.category === 'exam' ? 'Exam' :
                        notice.category === 'academic' ? 'Academic' :
                        notice.category === 'event' ? 'Event' : 'Urgent';
        
        noticeItem.innerHTML = `
            <div class="notice-header">
                <h4 class="notice-title">${notice.title}</h4>
                <span class="notice-badge ${badgeClass}">${badgeText}</span>
                <span class="notice-date"><i class="fas fa-calendar"></i> ${formatDate(notice.date)}</span>
            </div>
            <p class="notice-content">${notice.content}</p>
            <div class="notice-meta">
                <span class="notice-author">
                    <i class="fas fa-user"></i> ${notice.author}
                </span>
                <div class="notice-actions">
                    <button class="btn-read-more" onclick="viewNotice(${notice.id}); event.stopPropagation();">
                        <i class="fas fa-eye"></i> Read More
                    </button>
                    <button class="btn-mark-read" onclick="markAsRead(${notice.id}); event.stopPropagation();">
                        ${notice.read ? '<i class="fas fa-check"></i> Read' : '<i class="far fa-circle"></i> Mark Read'}
                    </button>
                </div>
            </div>
        `;
        noticesList.appendChild(noticeItem);
    });
}

function filterNotices(category) {
    loadNotices(category);
}

function searchNotices() {
    const searchTerm = document.getElementById('noticeSearch').value.toLowerCase();
    const filteredNotices = noticesData.filter(notice => 
        notice.title.toLowerCase().includes(searchTerm) ||
        notice.content.toLowerCase().includes(searchTerm) ||
        notice.author.toLowerCase().includes(searchTerm)
    );
    
    const noticesList = document.getElementById('noticesList');
    noticesList.innerHTML = '';
    
    if (filteredNotices.length === 0) {
        noticesList.innerHTML = `
            <div class="no-results">
                <i class="fas fa-search"></i>
                <h4>No notices found</h4>
                <p>Try different search terms</p>
            </div>
        `;
        return;
    }
    
    filteredNotices.forEach(notice => {
        const noticeItem = document.createElement('div');
        noticeItem.className = `notice-item ${notice.read ? '' : 'unread'} ${notice.priority === 'urgent' ? 'urgent' : ''}`;
        noticeItem.onclick = () => viewNotice(notice.id);
        
        const badgeClass = notice.category === 'exam' ? 'exam' :
                         notice.category === 'academic' ? 'academic' :
                         notice.category === 'event' ? 'event' : 'urgent';
        
        const badgeText = notice.category === 'exam' ? 'Exam' :
                        notice.category === 'academic' ? 'Academic' :
                        notice.category === 'event' ? 'Event' : 'Urgent';
        
        noticeItem.innerHTML = `
            <div class="notice-header">
                <h4 class="notice-title">${notice.title}</h4>
                <span class="notice-badge ${badgeClass}">${badgeText}</span>
                <span class="notice-date"><i class="fas fa-calendar"></i> ${formatDate(notice.date)}</span>
            </div>
            <p class="notice-content">${notice.content}</p>
            <div class="notice-meta">
                <span class="notice-author">
                    <i class="fas fa-user"></i> ${notice.author}
                </span>
                <div class="notice-actions">
                    <button class="btn-read-more" onclick="viewNotice(${notice.id}); event.stopPropagation();">
                        <i class="fas fa-eye"></i> Read More
                    </button>
                </div>
            </div>
        `;
        noticesList.appendChild(noticeItem);
    });
}

function viewNotice(noticeId) {
    const notice = noticesData.find(n => n.id === noticeId);
    if (!notice) return;
    
    // Mark as read
    if (!notice.read) {
        notice.read = true;
        updateUnreadCount();
    }
    
    // Update modal content
    document.getElementById('modalNoticeTitle').textContent = notice.title;
    
    let attachmentsHTML = '';
    if (notice.attachments && notice.attachments.length > 0) {
        attachmentsHTML = `
            <div class="notice-attachments">
                <h5>Attachments (${notice.attachments.length})</h5>
                <div class="attachment-list">
                    ${notice.attachments.map((attachment, index) => `
                        <div class="attachment-item">
                            <div class="attachment-icon">
                                <i class="fas fa-file-pdf"></i>
                            </div>
                            <div class="attachment-info">
                                <h6>${attachment.name}</h6>
                                <p>Size: ${attachment.size}</p>
                            </div>
                            <button class="btn-download-attachment" onclick="downloadAttachment(${noticeId}, ${index})">
                                <i class="fas fa-download"></i> Download
                            </button>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    const detailsHTML = `
        <h4>${notice.title}</h4>
        <div class="notice-meta-modal">
            <span class="notice-meta-item">
                <i class="fas fa-calendar"></i> ${formatDate(notice.date)}
            </span>
            <span class="notice-meta-item">
                <i class="fas fa-user"></i> ${notice.author}
            </span>
            <span class="notice-meta-item">
                <i class="fas fa-tag"></i> ${notice.category.charAt(0).toUpperCase() + notice.category.slice(1)} Notice
            </span>
            <span class="notice-meta-item">
                <i class="fas fa-exclamation-circle"></i> ${notice.priority === 'urgent' ? 'Urgent' : 'Normal'} Priority
            </span>
        </div>
        <div class="notice-content-full">
            <p>${notice.content}</p>
        </div>
        ${attachmentsHTML}
    `;
    
    document.getElementById('noticeDetails').innerHTML = detailsHTML;
    
    // Store current notice ID
    document.getElementById('noticeModal').setAttribute('data-notice-id', noticeId);
    
    // Show modal
    document.getElementById('noticeModal').classList.add('active');
}

function closeNoticeModal() {
    document.getElementById('noticeModal').classList.remove('active');
}

function markAsRead(noticeId) {
    event.stopPropagation();
    const notice = noticesData.find(n => n.id === noticeId);
    if (notice) {
        notice.read = true;
        updateUnreadCount();
        loadNotices(document.querySelector('.filter-btn.active').getAttribute('onclick').match(/'([^']+)'/)[1]);
    }
}

function markAllAsRead() {
    if (confirm('Mark all notices as read?')) {
        noticesData.forEach(notice => {
            notice.read = true;
        });
        updateUnreadCount();
        loadNotices(document.querySelector('.filter-btn.active').getAttribute('onclick').match(/'([^']+)'/)[1]);
    }
}

function updateUnreadCount() {
    const unreadCount = noticesData.filter(notice => !notice.read).length;
    document.getElementById('badgeCount').textContent = unreadCount;
    document.getElementById('unreadCount').style.display = unreadCount > 0 ? 'block' : 'none';
}

function downloadNotice() {
    const noticeId = document.getElementById('noticeModal').getAttribute('data-notice-id');
    const notice = noticesData.find(n => n.id === Number(noticeId));
    
    if (!notice) return;
    
    const noticeText = `
BEU COLLEGE NOTICE
===================

Title: ${notice.title}
Date: ${formatDate(notice.date)}
Author: ${notice.author}
Category: ${notice.category}
Priority: ${notice.priority}

CONTENT:
${notice.content}

${notice.attachments && notice.attachments.length > 0 ? `
ATTACHMENTS:
${notice.attachments.map(att => `- ${att.name} (${att.size})`).join('\n')}
` : ''}

---
Issued by: BEU College Portal
Date: ${new Date().toLocaleDateString()}
    `;
    
    const blob = new Blob([noticeText], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `BEU_Notice_${notice.title.replace(/\s+/g, '_')}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
}

function downloadAttachment(noticeId, attachmentIndex) {
    const notice = noticesData.find(n => n.id === noticeId);
    if (!notice || !notice.attachments || !notice.attachments[attachmentIndex]) return;
    
    const attachment = notice.attachments[attachmentIndex];
    alert(`Downloading: ${attachment.name}\n\nIn actual implementation, this would download the file from server.`);
}

function printNotice() {
    window.print();
}

function viewImportantNotice() {
    alert('Redirecting to exam schedule page...\n\nIn actual implementation, this would open the detailed notice.');
}

function changePage(direction) {
    alert(`Page navigation ${direction > 0 ? 'next' : 'previous'}\n\nIn actual implementation with backend, this would load more notices.`);
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}