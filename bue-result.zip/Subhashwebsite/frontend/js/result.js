// Result Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    const user = localStorage.getItem('studentUser');
    if (!user) {
        window.location.href = '../login.html';
        return;
    }
    
    const userData = JSON.parse(user);
    
    // Set default values in form
    document.getElementById('resultRoll').value = userData.rollno || '';
    
    // Time update
    function updateTime() {
        const now = new Date();
        const timeStr = now.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit',
            hour12: true 
        });
        document.getElementById('currentTime').textContent = timeStr;
    }
    updateTime();
    setInterval(updateTime, 60000);
    
    // Form submission
    const resultForm = document.getElementById('resultForm');
    resultForm.addEventListener('submit', function(e) {
        e.preventDefault();
        checkResult();
    });
    
    // Logout functionality
    document.getElementById('logoutBtn').addEventListener('click', function(e) {
        e.preventDefault();
        if (confirm('Are you sure you want to logout?')) {
            localStorage.removeItem('studentUser');
            window.location.href = '../login.html';
        }
    });
    
    // Load sample data on page load
    loadSampleResult();
});

// Sample result data
const sampleResults = {
    sem5: {
        student: {
            name: "Amit Kumar",
            rollno: "BEU2024001",
            branch: "Computer Science & Engineering",
            semester: "5th"
        },
        summary: {
            sgpa: "8.42",
            percentage: "78.5%",
            status: "PASS"
        },
        subjects: [
            { code: "CSE301", name: "Data Structures", internal: "28", external: "52", total: "80", grade: "A", status: "PASS" },
            { code: "CSE302", name: "Database Management", internal: "26", external: "48", total: "74", grade: "B+", status: "PASS" },
            { code: "CSE303", name: "Operating Systems", internal: "24", external: "46", total: "70", grade: "B", status: "PASS" },
            { code: "CSE304", name: "Computer Networks", internal: "27", external: "50", total: "77", grade: "A-", status: "PASS" },
            { code: "CSE305", name: "Theory of Computation", internal: "25", external: "45", total: "70", grade: "B", status: "PASS" },
            { code: "MATH301", name: "Discrete Mathematics", internal: "29", external: "55", total: "84", grade: "A+", status: "PASS" }
        ]
    },
    sem4: {
        student: {
            name: "Amit Kumar",
            rollno: "BEU2024001",
            branch: "Computer Science & Engineering",
            semester: "4th"
        },
        summary: {
            sgpa: "8.15",
            percentage: "76.2%",
            status: "PASS"
        },
        subjects: [
            { code: "CSE201", name: "Object Oriented Programming", internal: "27", external: "50", total: "77", grade: "A-", status: "PASS" },
            { code: "CSE202", name: "Digital Logic Design", internal: "25", external: "48", total: "73", grade: "B+", status: "PASS" },
            { code: "CSE203", name: "Computer Architecture", internal: "26", external: "49", total: "75", grade: "A-", status: "PASS" },
            { code: "CSE204", name: "Algorithms", internal: "24", external: "46", total: "70", grade: "B", status: "PASS" },
            { code: "MATH201", name: "Probability & Statistics", internal: "28", external: "52", total: "80", grade: "A", status: "PASS" }
        ]
    }
};

function checkResult() {
    const rollno = document.getElementById('resultRoll').value;
    const semester = document.getElementById('semester').value;
    const examType = document.getElementById('examType').value;
    
    if (!rollno || !semester) {
        alert('Please enter roll number and select semester');
        return;
    }
    
    // Show loading
    const checkBtn = document.querySelector('.btn-check-result');
    const originalText = checkBtn.innerHTML;
    checkBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Checking...';
    checkBtn.disabled = true;
    
    // Simulate API call
    setTimeout(() => {
        // For demo, always show sem5 result
        displayResult(sampleResults.sem5);
        
        // Restore button
        checkBtn.innerHTML = originalText;
        checkBtn.disabled = false;
    }, 1500);
}

function displayResult(resultData) {
    // Update student info
    document.getElementById('resultStudentName').textContent = resultData.student.name;
    document.getElementById('resultStudentRoll').textContent = resultData.student.rollno;
    document.getElementById('resultBranch').textContent = resultData.student.branch;
    document.getElementById('resultSemester').textContent = resultData.student.semester;
    
    // Update summary
    document.getElementById('sgpaValue').textContent = resultData.summary.sgpa;
    document.getElementById('percentageValue').textContent = resultData.summary.percentage;
    document.getElementById('resultStatus').textContent = resultData.summary.status;
    document.getElementById('resultStatus').className = `summary-value ${resultData.summary.status.toLowerCase()}`;
    
    // Update table
    const tableBody = document.getElementById('resultTableBody');
    tableBody.innerHTML = '';
    
    resultData.subjects.forEach(subject => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${subject.code}</td>
            <td class="subject-name">${subject.name}</td>
            <td>${subject.internal}/30</td>
            <td>${subject.external}/70</td>
            <td><strong>${subject.total}/100</strong></td>
            <td class="grade-${subject.grade.charAt(0).toLowerCase()}">${subject.grade}</td>
            <td class="status-${subject.status.toLowerCase()}">${subject.status}</td>
        `;
        tableBody.appendChild(row);
    });
    
    // Show result display
    document.getElementById('resultDisplay').style.display = 'block';
    
    // Scroll to result
    document.getElementById('resultDisplay').scrollIntoView({ 
        behavior: 'smooth',
        block: 'start'
    });
}

function loadResult(semester) {
    const result = sampleResults[semester] || sampleResults.sem5;
    displayResult(result);
}

function hideResult() {
    document.getElementById('resultDisplay').style.display = 'none';
}

function downloadResult() {
    alert('Result downloaded! (In real implementation, this would generate PDF)');
    
    // For demo, create a simple text file
    const resultText = `
BEU Result - Semester 5
Student: Amit Kumar
Roll No: BEU2024001
Branch: Computer Science & Engineering
SGPA: 8.42
Percentage: 78.5%
Status: PASS

Subject-wise Marks:
Data Structures: 80/100 (A)
Database Management: 74/100 (B+)
Operating Systems: 70/100 (B)
Computer Networks: 77/100 (A-)
Theory of Computation: 70/100 (B)
Discrete Mathematics: 84/100 (A+)
    `;
    
    const blob = new Blob([resultText], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `BEU_Result_${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
}

function loadSampleResult() {
    // Auto-load sample result for demo
    setTimeout(() => {
        displayResult(sampleResults.sem5);
    }, 1000);
}