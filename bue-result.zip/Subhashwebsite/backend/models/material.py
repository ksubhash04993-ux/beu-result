from app import db
from datetime import datetime

class Material(db.Model):
    """Study material model for notes and videos"""
    __tablename__ = 'materials'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    subject = db.Column(db.String(100), nullable=False)
    subject_code = db.Column(db.String(20), nullable=False)
    branch = db.Column(db.String(50), nullable=False)
    semester = db.Column(db.String(10), nullable=False)
    
    # Material type: 'note' or 'video'
    material_type = db.Column(db.String(10), nullable=False)
    file_url = db.Column(db.String(500))
    file_size = db.Column(db.String(20))
    duration = db.Column(db.String(20))  # For videos
    thumbnail_url = db.Column(db.String(500))  # For videos
    youtube_id = db.Column(db.String(100))  # For YouTube videos
    
    # Metadata
    author = db.Column(db.String(100))
    uploaded_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
    download_count = db.Column(db.Integer, default=0)
    view_count = db.Column(db.Integer, default=0)  # For videos
    is_featured = db.Column(db.Boolean, default=False)
    is_approved = db.Column(db.Boolean, default=True)
    
    # Tags/categories
    tags = db.Column(db.String(500))  # Comma separated tags
    
    def increment_download(self):
        """Increment download count"""
        self.download_count += 1
        db.session.commit()
    
    def increment_view(self):
        """Increment view count"""
        self.view_count += 1
        db.session.commit()
    
    def to_dict(self):
        """Convert material object to dictionary"""
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'subject': self.subject,
            'subject_code': self.subject_code,
            'branch': self.branch,
            'semester': self.semester,
            'material_type': self.material_type,
            'file_url': self.file_url,
            'file_size': self.file_size,
            'duration': self.duration,
            'thumbnail_url': self.thumbnail_url,
            'youtube_id': self.youtube_id,
            'author': self.author,
            'uploaded_by': self.uploaded_by,
            'uploaded_at': self.uploaded_at.isoformat() if self.uploaded_at else None,
            'download_count': self.download_count,
            'view_count': self.view_count,
            'is_featured': self.is_featured,
            'is_approved': self.is_approved,
            'tags': self.tags.split(',') if self.tags else []
        }
    
    def __repr__(self):
        return f'<Material {self.subject_code} - {self.title}>'