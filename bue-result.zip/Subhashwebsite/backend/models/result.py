from app import db
from datetime import datetime

class Result(db.Model):
    """Result model for student semester results"""
    __tablename__ = 'results'
    
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    semester = db.Column(db.String(10), nullable=False)
    exam_type = db.Column(db.String(20), default='regular')  # regular, back, improvement
    exam_year = db.Column(db.String(10), nullable=False)
    
    # Subject-wise marks
    subject_code = db.Column(db.String(20), nullable=False)
    subject_name = db.Column(db.String(100), nullable=False)
    internal_marks = db.Column(db.Integer, default=0)
    external_marks = db.Column(db.Integer, default=0)
    total_marks = db.Column(db.Integer, nullable=False)
    grade = db.Column(db.String(5))
    status = db.Column(db.String(10), default='PASS')  # PASS, FAIL
    
    # Overall result
    sgpa = db.Column(db.Float)
    percentage = db.Column(db.Float)
    result_status = db.Column(db.String(10), default='PASS')
    
    published_date = db.Column(db.DateTime, default=datetime.utcnow)
    published_by = db.Column(db.String(100))
    
    # Indexes
    __table_args__ = (
        db.Index('idx_student_semester', 'student_id', 'semester'),
        db.Index('idx_roll_semester', 'student_id', 'semester', 'exam_type'),
    )
    
    def to_dict(self):
        """Convert result object to dictionary"""
        return {
            'id': self.id,
            'student_id': self.student_id,
            'semester': self.semester,
            'exam_type': self.exam_type,
            'exam_year': self.exam_year,
            'subject_code': self.subject_code,
            'subject_name': self.subject_name,
            'internal_marks': self.internal_marks,
            'external_marks': self.external_marks,
            'total_marks': self.total_marks,
            'grade': self.grade,
            'status': self.status,
            'sgpa': self.sgpa,
            'percentage': self.percentage,
            'result_status': self.result_status,
            'published_date': self.published_date.isoformat() if self.published_date else None,
            'published_by': self.published_by
        }
    
    def __repr__(self):
        return f'<Result {self.student_id} - Sem {self.semester}>'