/**
 * BEU Result Fetcher for Frontend
 * Connects to backend and handles result retrieval
 */

class BEUResultFetcher {
    constructor() {
        this.apiBase = 'http://localhost:5000/api';
        this.cache = new Map();
    }
    
    async checkResultStatus() {
        /** Check if BEU results are declared */
        try {
            const response = await fetch(`${this.apiBase}/beu/status`);
            const data = await response.json();
            
            return data;
        } catch (error) {
            console.error('Error checking result status:', error);
            return {
                success: false,
                message: 'Network error'
            };
        }
    }
    
    async fetchResult(rollNo, semester, examYear) {
        /** Fetch result from BEU */
        try {
            const response = await fetch(`${this.apiBase}/beu/check`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('access_token')}`
                },
                body: JSON.stringify({
                    roll_no: rollNo,
                    semester: semester,
                    exam_year: examYear
                })
            });
            
            const data = await response.json();
            
            // Cache the result
            if (data.success) {
                const cacheKey = `${rollNo}_${semester}_${examYear}`;
                this.cache.set(cacheKey, {
                    data: data.data,
                    timestamp: Date.now()
                });
                
                // Save to localStorage for offline access
                this.saveToLocalStorage(rollNo, semester, examYear, data.data);
            }
            
            return data;
        } catch (error) {
            console.error('Error fetching result:', error);
            return {
                success: false,
                message: 'Network error. Please check your connection.'
            };
        }
    }
    
    async fetchUsingMultipleMethods(rollNo, semester) {
        /** Try multiple methods to get result */
        const methods = [
            this.fetchResult(rollNo, semester, new Date().getFullYear()),
            this.checkTelegramChannels(rollNo),
            this.checkThirdPartySites(rollNo, semester)
        ];
        
        try {
            const results = await Promise.allSettled(methods);
            
            const successfulResults = results
                .filter(r => r.status === 'fulfilled' && r.value?.success)
                .map(r => r.value);
            
            if (successfulResults.length > 0) {
                // Return the most reliable result
                return successfulResults[0];
            } else {
                return {
                    success: false,
                    message: 'Result not found using any method'
                };
            }
        } catch (error) {
            return {
                success: false,
                message: 'Error fetching result'
            };
        }
    }
    
    async checkTelegramChannels(rollNo) {
        /** Check Telegram channels for result */
        // Note: This requires backend support
        try {
            const response = await fetch(`${this.apiBase}/beu/telegram-check`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ roll_no: rollNo })
            });
            
            return await response.json();
        } catch (error) {
            return {
                success: false,
                method: 'telegram',
                message: 'Telegram check failed'
            };
        }
    }
    
    async checkThirdPartySites(rollNo, semester) {
        /** Check third-party result websites */
        const sites = [
            {
                name: 'biharresult.com',
                url: `https://biharresult.com/beu/${rollNo}/${semester}`
            },
            {
                name: 'indiaresults.com',
                url: `https://indiaresults.com/bihar/beu/${rollNo}`
            }
        ];
        
        // This would require backend scraping
        // For now, return placeholder
        return {
            success: false,
            method: 'third_party',
            message: 'Third-party check requires backend implementation',
            sites: sites
        };
    }
    
    saveToLocalStorage(rollNo, semester, year, resultData) {
        /** Save result to localStorage for offline access */
        try {
            const savedResults = JSON.parse(localStorage.getItem('beu_results') || '{}');
            
            const key = `${rollNo}_${semester}_${year}`;
            savedResults[key] = {
                data: resultData,
                saved_at: new Date().toISOString(),
                expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() // 30 days
            };
            
            localStorage.setItem('beu_results', JSON.stringify(savedResults));
        } catch (error) {
            console.error('Error saving to localStorage:', error);
        }
    }
    
    getFromLocalStorage(rollNo, semester, year) {
        /** Get cached result from localStorage */
        try {
            const savedResults = JSON.parse(localStorage.getItem('beu_results') || '{}');
            const key = `${rollNo}_${semester}_${year}`;
            
            if (savedResults[key]) {
                const result = savedResults[key];
                
                // Check if expired
                if (new Date(result.expires_at) > new Date()) {
                    return {
                        success: true,
                        data: result.data,
                        cached: true,
                        saved_at: result.saved_at
                    };
                } else {
                    // Remove expired result
                    delete savedResults[key];
                    localStorage.setItem('beu_results', JSON.stringify(savedResults));
                }
            }
            
            return null;
        } catch (error) {
            return null;
        }
    }
    
    async manualResultUpload(resultData) {
        /** Manually upload result data */
        try {
            const response = await fetch(`${this.apiBase}/beu/manual-upload`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('access_token')}`
                },
                body: JSON.stringify(resultData)
            });
            
            return await response.json();
        } catch (error) {
            return {
                success: false,
                message: 'Upload failed'
            };
        }
    }
    
    displayResult(resultData, containerId) {
        /** Display result in HTML */
        const container = document.getElementById(containerId);
        if (!container) return;
        
        if (!resultData.success) {
            container.innerHTML = `
                <div class="alert alert-danger">
                    <h4>Result Not Found</h4>
                    <p>${resultData.message}</p>
                    <div class="mt-3">
                        <h5>Try These:</h5>
                        <ul>
                            <li><a href="http://results.beu-bih.ac.in/" target="_blank">Official BEU Result Portal</a></li>
                            <li><a href="https://beu-bih.ac.in" target="_blank">BEU Official Website</a></li>
                            <li>Check Telegram Channel: @beuresults</li>
                        </ul>
                    </div>
                </div>
            `;
            return;
        }
        
        const data = resultData.data;
        
        let html = `
            <div class="result-card">
                <div class="result-header">
                    <h3>BEU Result - Semester ${data.semester || ''}</h3>
                    <p>Roll No: ${data.roll_no}</p>
                </div>
                
                <div class="student-info">
        `;
        
        // Student info
        if (data.student_info && Object.keys(data.student_info).length > 0) {
            html += '<h4>Student Information</h4>';
            for (const [key, value] of Object.entries(data.student_info)) {
                html += `<p><strong>${key}:</strong> ${value}</p>`;
            }
        }
        
        // Overall result
        if (data.overall && Object.keys(data.overall).length > 0) {
            html += '<div class="overall-result">';
            html += '<h4>Overall Result</h4>';
            for (const [key, value] of Object.entries(data.overall)) {
                html += `<p><strong>${key}:</strong> ${value}</p>`;
            }
            html += '</div>';
        }
        
        // Subjects table
        if (data.subjects && data.subjects.length > 0) {
            html += `
                <h4>Subject-wise Marks</h4>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Subject Code</th>
                                <th>Subject Name</th>
                                <th>Internal</th>
                                <th>External</th>
                                <th>Total</th>
                                <th>Grade</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
            `;
            
            data.subjects.forEach(subject => {
                html += `
                    <tr>
                        <td>${subject.code || ''}</td>
                        <td>${subject.name || ''}</td>
                        <td>${subject.internal || ''}</td>
                        <td>${subject.external || ''}</td>
                        <td>${subject.total || ''}</td>
                        <td>${subject.grade || ''}</td>
                        <td class="${subject.status === 'PASS' ? 'text-success' : 'text-danger'}">
                            ${subject.status || ''}
                        </td>
                    </tr>
                `;
            });
            
            html += `
                        </tbody>
                    </table>
                </div>
            `;
        }
        
        html += `
                </div>
                
                <div class="result-actions mt-3">
                    <button class="btn btn-primary" onclick="printResult()">
                        <i class="fas fa-print"></i> Print Result
                    </button>
                    <button class="btn btn-success" onclick="downloadResult()">
                        <i class="fas fa-download"></i> Download PDF
                    </button>
                    ${resultData.cached ? 
                        '<span class="text-muted ms-3"><i class="fas fa-history"></i> Cached Result</span>' : 
                        ''}
                </div>
            </div>
        `;
        
        container.innerHTML = html;
    }
    
    generateMockResult(rollNo, semester) {
        /** Generate mock result for testing */
        return {
            success: true,
            data: {
                roll_no: rollNo,
                semester: semester,
                student_info: {
                    'Name': 'Test Student',
                    'Roll No': rollNo,
                    'Branch': 'Computer Science & Engineering',
                    'Semester': semester,
                    'Exam Year': new Date().getFullYear()
                },
                subjects: [
                    {
                        code: 'CSE301',
                        name: 'Data Structures',
                        internal: '28',
                        external: '52',
                        total: '80',
                        grade: 'A',
                        status: 'PASS'
                    },
                    {
                        code: 'CSE302',
                        name: 'Database Management',
                        internal: '26',
                        external: '48',
                        total: '74',
                        grade: 'B+',
                        status: 'PASS'
                    }
                ],
                overall: {
                    'SGPA': '8.42',
                    'Percentage': '78.5%',
                    'Result': 'PASS'
                }
            },
            method: 'mock',
            timestamp: new Date().toISOString()
        };
    }
}

// Global instance
window.beuResultFetcher = new BEUResultFetcher();

// Helper functions
async function fetchAndDisplayResult() {
    const rollNo = document.getElementById('rollNoInput').value;
    const semester = document.getElementById('semesterSelect').value;
    
    if (!rollNo || !semester) {
        alert('Please enter roll number and select semester');
        return;
    }
    
    // Show loading
    const container = document.getElementById('resultContainer');
    container.innerHTML = `
        <div class="text-center">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-2">Fetching result from BEU...</p>
            <p class="text-muted small">Checking multiple sources</p>
        </div>
    `;
    
    // Check cache first
    const cached = window.beuResultFetcher.getFromLocalStorage(rollNo, semester, new Date().getFullYear());
    
    if (cached) {
        window.beuResultFetcher.displayResult(cached, 'resultContainer');
        return;
    }
    
    // Fetch from server
    const result = await window.beuResultFetcher.fetchUsingMultipleMethods(rollNo, semester);
    
    if (!result.success) {
        // Try mock data for demo
        if (rollNo === 'test' || rollNo === 'BEU2024001') {
            const mockResult = window.beuResultFetcher.generateMockResult(rollNo, semester);
            window.beuResultFetcher.displayResult(mockResult, 'resultContainer');
        } else {
            window.beuResultFetcher.displayResult(result, 'resultContainer');
        }
    } else {
        window.beuResultFetcher.displayResult(result, 'resultContainer');
    }
}

function printResult() {
    window.print();
}

async function downloadResult() {
    // Generate PDF of result
    alert('PDF download would be implemented here. For now, use Print function.');
}

// Auto-check result status on page load
document.addEventListener('DOMContentLoaded', async function() {
    // Check if on result page
    if (window.location.pathname.includes('result')) {
        const status = await window.beuResultFetcher.checkResultStatus();
        
        if (status.success && status.results_declared) {
            // Show notification
            const noticeDiv = document.createElement('div');
            noticeDiv.className = 'alert alert-success alert-dismissible fade show';
            noticeDiv.innerHTML = `
                <i class="fas fa-bullhorn"></i>
                <strong>BEU Results Declared!</strong> 
                ${status.announcements?.length ? `${status.announcements[0].title}` : ''}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            `;
            
            document.querySelector('.container').prepend(noticeDiv);
        }
    }
});