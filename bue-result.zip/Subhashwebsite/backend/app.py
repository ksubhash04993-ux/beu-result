from flask import Flask, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from config import config
import os

# Initialize extensions
db = SQLAlchemy()
jwt = JWTManager()
cors = CORS()

def create_app(config_name='default'):
    """Application factory function"""
    app = Flask(__name__)
    
    # Load configuration
    app.config.from_object(config[config_name])
    config[config_name].init_app(app)
    
    # Initialize extensions
    db.init_app(app)
    jwt.init_app(app)
    cors.init_app(app, origins=app.config['CORS_ORIGINS'])
    
    # Ensure upload directories exist
    create_upload_dirs(app)
    
    # Register blueprints
    register_blueprints(app)
    
    # Create database tables
    with app.app_context():
        db.create_all()
        create_default_admin()
    
    # Error handlers
    register_error_handlers(app)
    
    return app

def create_upload_dirs(app):
    """Create upload directories if they don't exist"""
    upload_dirs = [
        os.path.join(app.config['UPLOAD_FOLDER'], 'notes'),
        os.path.join(app.config['UPLOAD_FOLDER'], 'videos'),
        os.path.join(app.config['UPLOAD_FOLDER'], 'notices'),
        os.path.join(app.config['UPLOAD_FOLDER'], 'profile_pics')
    ]
    
    for dir_path in upload_dirs:
        os.makedirs(dir_path, exist_ok=True)

def register_blueprints(app):
    """Register all API blueprints"""
    from routes.auth import auth_bp
    from routes.student import student_bp
    from routes.materials import materials_bp
    from routes.notices import notices_bp
    from routes.admin import admin_bp
    
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(student_bp, url_prefix='/api/student')
    app.register_blueprint(materials_bp, url_prefix='/api/materials')
    app.register_blueprint(notices_bp, url_prefix='/api/notices')
    app.register_blueprint(admin_bp, url_prefix='/api/admin')

def create_default_admin():
    """Create default admin user if not exists"""
    from models.user import User
    
    admin = User.query.filter_by(email='admin@beu.edu.in').first()
    if not admin:
        admin = User(
            name='Admin',
            email='admin@beu.edu.in',
            password='admin123',  # Will be hashed in __init__
            roll_no='ADMIN001',
            role='admin',
            branch='admin',
            semester='0'
        )
        db.session.add(admin)
        db.session.commit()
        print("Default admin user created")

def register_error_handlers(app):
    """Register error handlers"""
    
    @app.errorhandler(404)
    def not_found(error):
        return jsonify({
            'success': False,
            'message': 'Resource not found',
            'error': str(error)
        }), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        return jsonify({
            'success': False,
            'message': 'Internal server error',
            'error': str(error)
        }), 500
    
    @app.errorhandler(401)
    def unauthorized(error):
        return jsonify({
            'success': False,
            'message': 'Unauthorized access',
            'error': str(error)
        }), 401

# Create app instance
app = create_app()

if __name__ == '__main__':
    app.run(debug=True, port=5000)