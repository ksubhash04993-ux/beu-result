"""
Instance-specific configuration
This file is not tracked in git
"""

import os

# Database paths
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATABASE_PATH = os.path.join(BASE_DIR, 'instance', 'portal.db')
BACKUP_DIR = os.path.join(BASE_DIR, 'instance', 'backups')

# Create backup directory
os.makedirs(BACKUP_DIR, exist_ok=True)

# Instance settings
INSTANCE_ID = os.environ.get('INSTANCE_ID', 'beu_portal_001')
INSTANCE_NAME = os.environ.get('INSTANCE_NAME', 'BEU College Portal')
INSTANCE_VERSION = '1.0.0'

# Admin settings (override in production)
ADMIN_EMAIL = os.environ.get('ADMIN_EMAIL', 'admin@beu.edu.in')
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'admin123')

# BEU Settings
BEU_OFFICIAL_URL = 'https://beu-bih.ac.in'
BEU_RESULT_URL = 'http://results.beu-bih.ac.in/'
BEU_CONTACT_EMAIL = 'contact@beu-bih.ac.in'

# College Settings
COLLEGE_NAME = 'Bihar Engineering University'
COLLEGE_ADDRESS = 'Patna, Bihar - 800001'
COLLEGE_PHONE = '+91 123 456 7890'

# Academic Settings
CURRENT_ACADEMIC_YEAR = '2023-2024'
CURRENT_SEMESTER = '5'
EXAM_SESSION = 'Odd Semester 2024'

# File upload settings (instance specific)
MAX_UPLOAD_SIZE = 16 * 1024 * 1024  # 16MB
ALLOWED_FILE_TYPES = {
    'notes': ['.pdf', '.doc', '.docx', '.txt'],
    'videos': ['.mp4', '.avi', '.mov', '.mkv'],
    'images': ['.jpg', '.jpeg', '.png', '.gif']
}

# Backup settings
BACKUP_SCHEDULE = 'daily'  # daily, weekly, monthly
KEEP_BACKUPS = 7  # Number of backups to keep

# Logging settings
LOG_LEVEL = 'INFO'
LOG_FILE = os.path.join(BASE_DIR, 'instance', 'app.log')

# Security settings (override in production)
SESSION_TIMEOUT = 3600  # 1 hour in seconds
MAX_LOGIN_ATTEMPTS = 5

def get_database_uri():
    """Get database URI based on environment"""
    import sys
    
    if 'pytest' in sys.modules:
        # Test database
        return 'sqlite:///:memory:'
    elif os.environ.get('DATABASE_URL'):
        # Production database (PostgreSQL)
        return os.environ.get('DATABASE_URL')
    else:
        # Development database
        return f'sqlite:///{DATABASE_PATH}'

def get_instance_info():
    """Get instance information"""
    import socket
    import platform
    
    return {
        'instance_id': INSTANCE_ID,
        'instance_name': INSTANCE_NAME,
        'version': INSTANCE_VERSION,
        'hostname': socket.gethostname(),
        'platform': platform.platform(),
        'python_version': platform.python_version(),
        'database_path': DATABASE_PATH,
        'backup_dir': BACKUP_DIR,
        'college_name': COLLEGE_NAME,
        'academic_year': CURRENT_ACADEMIC_YEAR
    }

def print_instance_info():
    """Print instance information"""
    info = get_instance_info()
    
    print("\n" + "="*60)
    print("BEU COLLEGE PORTAL - INSTANCE INFORMATION")
    print("="*60)
    
    for key, value in info.items():
        print(f"{key.replace('_', ' ').title():25}: {value}")
    
    print("="*60)
    print(f"Database: {os.path.exists(DATABASE_PATH) and 'Exists' or 'Not Found'}")
    print(f"Backup Dir: {os.path.exists(BACKUP_DIR) and 'Exists' or 'Not Found'}")
    print("="*60 + "\n")

if __name__ == '__main__':
    print_instance_info()