# BEU College Portal

A complete college management system with student portal, study materials, results, and admin panel.

## Features

### For Students:
- ✅ Student Registration & Login
- ✅ Dashboard with Stats
- ✅ Check Semester Results
- ✅ Download Study Notes
- ✅ Watch Video Lectures
- ✅ View College Notices
- ✅ Profile Management

### For Admin:
- ✅ User Management
- ✅ Upload Study Materials
- ✅ Publish Notices
- ✅ Manage Results
- ✅ System Statistics
- ✅ Database Backup

## Technology Stack

### Frontend:
- HTML5, CSS3, JavaScript
- Responsive Design
- Mobile Friendly

### Backend:
- Python Flask
- SQLAlchemy ORM
- JWT Authentication
- RESTful API

### Database:
- SQLite (Development)
- MySQL/PostgreSQL (Production)

## Project Structure
