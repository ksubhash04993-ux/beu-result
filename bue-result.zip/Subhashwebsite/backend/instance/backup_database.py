#!/usr/bin/env python3
"""
Database backup utility for BEU Portal
Run this script to create database backups
"""

import os
import sys
import shutil
import sqlite3
from datetime import datetime
import gzip
import json

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from instance.config import DATABASE_PATH, BACKUP_DIR, BACKUP_SCHEDULE, KEEP_BACKUPS

def create_backup():
    """Create database backup"""
    try:
        # Check if database exists
        if not os.path.exists(DATABASE_PATH):
            print(f"❌ Database not found: {DATABASE_PATH}")
            return None
        
        # Create backup filename with timestamp
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_file = os.path.join(BACKUP_DIR, f'portal_backup_{timestamp}.db')
        
        print(f"🔧 Creating backup: {backup_file}")
        
        # Create backup using SQLite backup API
        source = sqlite3.connect(DATABASE_PATH)
        backup = sqlite3.connect(backup_file)
        
        with backup:
            source.backup(backup)
        
        source.close()
        backup.close()
        
        # Compress backup
        compressed_file = backup_file + '.gz'
        with open(backup_file, 'rb') as f_in:
            with gzip.open(compressed_file, 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
        
        # Remove uncompressed backup
        os.remove(backup_file)
        
        # Create backup info file
        backup_info = {
            'filename': os.path.basename(compressed_file),
            'created_at': datetime.now().isoformat(),
            'size_bytes': os.path.getsize(compressed_file),
            'size_human': f"{os.path.getsize(compressed_file) / 1024 / 1024:.2f} MB",
            'database_size': os.path.getsize(DATABASE_PATH),
            'backup_type': 'full'
        }
        
        info_file = compressed_file.replace('.db.gz', '.json')
        with open(info_file, 'w') as f:
            json.dump(backup_info, f, indent=2)
        
        print(f"✅ Backup created: {compressed_file}")
        print(f"   Size: {backup_info['size_human']}")
        
        # Clean old backups
        clean_old_backups()
        
        return backup_info
        
    except Exception as e:
        print(f"❌ Backup failed: {e}")
        return None

def clean_old_backups():
    """Remove old backups beyond KEEP_BACKUPS limit"""
    try:
        # List all backup files
        backup_files = []
        for file in os.listdir(BACKUP_DIR):
            if file.endswith('.db.gz'):
                filepath = os.path.join(BACKUP_DIR, file)
                backup_files.append((filepath, os.path.getmtime(filepath)))
        
        # Sort by modification time (oldest first)
        backup_files.sort(key=lambda x: x[1])
        
        # Remove old backups
        if len(backup_files) > KEEP_BACKUPS:
            files_to_remove = backup_files[:-KEEP_BACKUPS]
            
            for filepath, _ in files_to_remove:
                # Remove backup file and info file
                os.remove(filepath)
                
                info_file = filepath.replace('.db.gz', '.json')
                if os.path.exists(info_file):
                    os.remove(info_file)
                
                print(f"🗑️  Removed old backup: {os.path.basename(filepath)}")
        
        return True
        
    except Exception as e:
        print(f"❌ Cleanup failed: {e}")
        return False

def list_backups():
    """List all available backups"""
    try:
        backups = []
        
        for file in os.listdir(BACKUP_DIR):
            if file.endswith('.db.gz'):
                filepath = os.path.join(BACKUP_DIR, file)
                info_file = filepath.replace('.db.gz', '.json')
                
                backup_info = {
                    'filename': file,
                    'path': filepath,
                    'size': os.path.getsize(filepath),
                    'modified': datetime.fromtimestamp(os.path.getmtime(filepath)).isoformat()
                }
                
                # Load additional info if available
                if os.path.exists(info_file):
                    with open(info_file, 'r') as f:
                        info = json.load(f)
                        backup_info.update(info)
                
                backups.append(backup_info)
        
        # Sort by date (newest first)
        backups.sort(key=lambda x: x.get('created_at', x['modified']), reverse=True)
        
        return backups
        
    except Exception as e:
        print(f"❌ Failed to list backups: {e}")
        return []

def restore_backup(backup_filename):
    """Restore database from backup"""
    try:
        backup_path = os.path.join(BACKUP_DIR, backup_filename)
        
        if not os.path.exists(backup_path):
            print(f"❌ Backup not found: {backup_path}")
            return False
        
        print(f"🔧 Restoring from backup: {backup_filename}")
        
        # Extract backup
        temp_backup = backup_path.replace('.gz', '')
        
        with gzip.open(backup_path, 'rb') as f_in:
            with open(temp_backup, 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
        
        # Backup current database first
        current_backup = create_backup()
        if current_backup:
            print(f"📋 Current database backed up: {current_backup['filename']}")
        
        # Close any existing connections
        import sqlite3
        try:
            # Try to close database if open
            pass
        except:
            pass
        
        # Replace database
        if os.path.exists(DATABASE_PATH):
            os.remove(DATABASE_PATH)
        
        shutil.copy(temp_backup, DATABASE_PATH)
        
        # Cleanup
        os.remove(temp_backup)
        
        print(f"✅ Database restored from: {backup_filename}")
        return True
        
    except Exception as e:
        print(f"❌ Restore failed: {e}")
        return False

def backup_stats():
    """Get backup statistics"""
    try:
        backups = list_backups()
        
        total_size = sum(b['size'] for b in backups)
        total_count = len(backups)
        
        if backups:
            latest = backups[0]
            oldest = backups[-1]
        else:
            latest = oldest = None
        
        return {
            'total_backups': total_count,
            'total_size_bytes': total_size,
            'total_size_human': f"{total_size / 1024 / 1024:.2f} MB",
            'latest_backup': latest,
            'oldest_backup': oldest,
            'backup_dir': BACKUP_DIR,
            'keep_backups': KEEP_BACKUPS
        }
        
    except Exception as e:
        print(f"❌ Stats failed: {e}")
        return {}

def auto_backup():
    """Automatic backup based on schedule"""
    try:
        from datetime import datetime
        
        today = datetime.now().strftime('%Y%m%d')
        last_backup_file = os.path.join(BACKUP_DIR, 'last_backup.txt')
        
        # Check if backup already done today
        if os.path.exists(last_backup_file):
            with open(last_backup_file, 'r') as f:
                last_date = f.read().strip()
            
            if last_date == today and BACKUP_SCHEDULE == 'daily':
                print("📅 Backup already done today")
                return None
        
        # Create backup
        result = create_backup()
        
        if result:
            # Update last backup date
            with open(last_backup_file, 'w') as f:
                f.write(today)
        
        return result
        
    except Exception as e:
        print(f"❌ Auto backup failed: {e}")
        return None

if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='BEU Portal Database Backup Utility')
    parser.add_argument('--create', action='store_true', help='Create new backup')
    parser.add_argument('--list', action='store_true', help='List all backups')
    parser.add_argument('--stats', action='store_true', help='Show backup statistics')
    parser.add_argument('--restore', help='Restore from backup (filename)')
    parser.add_argument('--auto', action='store_true', help='Automatic backup')
    parser.add_argument('--clean', action='store_true', help='Clean old backups')
    
    args = parser.parse_args()
    
    if args.create:
        create_backup()
    elif args.list:
        backups = list_backups()
        if backups:
            print("\n📊 Available Backups:")
            print("-" * 80)
            for i, backup in enumerate(backups, 1):
                print(f"{i:2}. {backup['filename']:40} {backup.get('size_human', 'N/A'):10} {backup.get('created_at', backup['modified'])[:19]}")
        else:
            print("❌ No backups found")
    elif args.stats:
        stats = backup_stats()
        if stats:
            print("\n📈 Backup Statistics:")
            print("-" * 40)
            for key, value in stats.items():
                if key not in ['latest_backup', 'oldest_backup']:
                    print(f"{key.replace('_', ' ').title():20}: {value}")
    elif args.restore:
        if restore_backup(args.restore):
            print("✅ Restore completed successfully")
        else:
            print("❌ Restore failed")
    elif args.auto:
        auto_backup()
    elif args.clean:
        clean_old_backups()
    else:
        # Show help
        parser.print_help()
        
        # Show quick stats
        print("\n💡 Quick Info:")
        print(f"Database: {DATABASE_PATH}")
        print(f"Exists: {os.path.exists(DATABASE_PATH)}")
        print(f"Backup Dir: {BACKUP_DIR}")
        print(f"Backups: {len(list_backups())}")