// Profile Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    const user = localStorage.getItem('studentUser');
    if (!user) {
        window.location.href = '../login.html';
        return;
    }
    
    const userData = JSON.parse(user);
    
    // Load profile data
    loadProfileData(userData);
    
    // Time update
    function updateTime() {
        const now = new Date();
        const timeStr = now.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit',
            hour12: true 
        });
        document.getElementById('currentTime').textContent = timeStr;
    }
    updateTime();
    setInterval(updateTime, 60000);
    
    // Logout functionality
    document.getElementById('logoutBtn').addEventListener('click', function(e) {
        e.preventDefault();
        if (confirm('Are you sure you want to logout?')) {
            localStorage.removeItem('studentUser');
            window.location.href = '../login.html';
        }
    });
    
    // Theme toggle
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        themeToggle.addEventListener('change', function() {
            if (this.checked) {
                document.body.classList.add('dark-mode');
                localStorage.setItem('theme', 'dark');
            } else {
                document.body.classList.remove('dark-mode');
                localStorage.setItem('theme', 'light');
            }
        });
        
        // Load saved theme
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            themeToggle.checked = true;
            document.body.classList.add('dark-mode');
        }
    }
    
    // Password strength check
    const newPasswordInput = document.getElementById('newPassword');
    if (newPasswordInput) {
        newPasswordInput.addEventListener('input', checkPasswordStrength);
    }
});

// Sample profile data
const profileData = {
    name: "Amit Kumar",
    rollno: "BEU2024001",
    email: "amit.kumar@beu.edu.in",
    phone: "+91 98765 43210",
    dob: "15 March 2002",
    gender: "Male",
    address: "Patna, Bihar - 800001",
    college: "Bihar Engineering University",
    branch: "Computer Science & Engineering",
    semester: "5th Semester",
    year: "2023-2024",
    enrollment: "BEU/CSE/2020/001",
    percentage: "78.5%",
    subjects: 5,
    notesDownloaded: 24,
    videoWatched: "15h",
    avatarInitials: "AK"
};

function loadProfileData(userData) {
    // Set user info in sidebar
    document.getElementById('studentName').textContent = userData.name || profileData.name;
    document.getElementById('studentRoll').textContent = `Roll No: ${userData.rollno || profileData.rollno}`;
    
    // Set profile header info
    document.getElementById('profileFullName').textContent = userData.name || profileData.name;
    document.getElementById('profileAvatar').innerHTML = `<span>${getInitials(userData.name || profileData.name)}</span>`;
    
    // Set personal information
    document.getElementById('infoRollNo').textContent = userData.rollno || profileData.rollno;
    document.getElementById('infoEmail').textContent = userData.email || profileData.email;
    document.getElementById('infoPhone').textContent = profileData.phone;
    document.getElementById('infoDob').textContent = profileData.dob;
    document.getElementById('infoGender').textContent = profileData.gender;
    document.getElementById('infoAddress').textContent = profileData.address;
    
    // Set academic information
    document.getElementById('infoCollege').textContent = profileData.college;
    document.getElementById('infoBranch').textContent = userData.branch || profileData.branch;
    document.getElementById('infoSemester').textContent = userData.semester ? `${userData.semester}th Semester` : profileData.semester;
    document.getElementById('infoYear').textContent = profileData.year;
    document.getElementById('infoEnrollment').textContent = profileData.enrollment;
    document.getElementById('infoPercentage').textContent = profileData.percentage;
    
    // Update stats
    updateStats();
}

function getInitials(name) {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
}

function updateStats() {
    // In actual implementation, this would fetch real stats
    const stats = {
        subjects: profileData.subjects,
        notes: profileData.notesDownloaded,
        videos: profileData.videoWatched,
        percentage: profileData.percentage
    };
    
    document.querySelectorAll('.stat-item span')[0].textContent = `${stats.subjects} Subjects`;
    document.querySelectorAll('.stat-item span')[1].textContent = `${stats.notes} Notes`;
    document.querySelectorAll('.stat-item span')[2].textContent = `${stats.videos} Watched`;
    document.querySelectorAll('.stat-item span')[3].textContent = `${stats.percentage} Average`;
}

function editProfile() {
    const modalTitle = document.getElementById('modalTitle');
    modalTitle.textContent = 'Edit Personal Information';
    
    // Fill form with current data
    document.getElementById('editName').value = profileData.name;
    document.getElementById('editEmail').value = profileData.email;
    document.getElementById('editPhone').value = profileData.phone;
    document.getElementById('editAddress').value = profileData.address;
    
    // Show modal
    document.getElementById('editModal').classList.add('active');
}

function editPersonalInfo() {
    editProfile();
}

function editAcademicInfo() {
    alert('Academic information can only be updated by admin. Please contact college administration for changes.');
}

function closeEditModal() {
    document.getElementById('editModal').classList.remove('active');
}

function saveProfile() {
    // Get form values
    const name = document.getElementById('editName').value;
    const email = document.getElementById('editEmail').value;
    const phone = document.getElementById('editPhone').value;
    const address = document.getElementById('editAddress').value;
    
    // Validation
    if (!name || !email) {
        alert('Name and email are required');
        return;
    }
    
    // Update profile data
    profileData.name = name;
    profileData.email = email;
    profileData.phone = phone;
    profileData.address = address;
    
    // Update user data in localStorage
    const userData = JSON.parse(localStorage.getItem('studentUser') || '{}');
    userData.name = name;
    userData.email = email;
    localStorage.setItem('studentUser', JSON.stringify(userData));
    
    // Reload profile data
    loadProfileData(userData);
    
    // Close modal
    closeEditModal();
    
    // Show success message
    alert('Profile updated successfully!');
}

function changeAvatar() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    
    input.onchange = function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                // Update avatar preview
                const avatarCircle = document.getElementById('profileAvatar');
                avatarCircle.innerHTML = `<img src="${e.target.result}" alt="Profile" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">`;
                
                // Save to localStorage (in real app, upload to server)
                localStorage.setItem('profileAvatar', e.target.result);
                
                alert('Profile photo updated successfully!');
            };
            reader.readAsDataURL(file);
        }
    };
    
    input.click();
}

function changePassword() {
    document.getElementById('passwordModal').classList.add('active');
}

function closePasswordModal() {
    document.getElementById('passwordModal').classList.remove('active');
    // Clear form
    document.getElementById('passwordForm').reset();
    document.querySelector('.strength-bar').style.width = '0%';
    document.querySelector('.strength-text').textContent = 'Password strength: None';
}

function checkPasswordStrength() {
    const password = document.getElementById('newPassword').value;
    const strengthBar = document.querySelector('.strength-bar');
    const strengthText = document.querySelector('.strength-text');
    
    let strength = 0;
    
    // Length check
    if (password.length >= 8) strength += 25;
    if (password.length >= 12) strength += 10;
    
    // Complexity checks
    if (/[A-Z]/.test(password)) strength += 20;
    if (/[a-z]/.test(password)) strength += 20;
    if (/[0-9]/.test(password)) strength += 20;
    if (/[^A-Za-z0-9]/.test(password)) strength += 25;
    
    // Update UI
    strengthBar.style.width = `${strength}%`;
    
    if (strength < 40) {
        strengthBar.style.backgroundColor = '#f44336';
        strengthText.textContent = 'Password strength: Weak';
    } else if (strength < 70) {
        strengthBar.style.backgroundColor = '#ff9800';
        strengthText.textContent = 'Password strength: Fair';
    } else if (strength < 90) {
        strengthBar.style.backgroundColor = '#4CAF50';
        strengthText.textContent = 'Password strength: Good';
    } else {
        strengthBar.style.backgroundColor = '#2E7D32';
        strengthText.textContent = 'Password strength: Strong';
    }
}

function changePasswordSubmit() {
    const currentPassword = document.getElementById('currentPassword').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    // Validation
    if (!currentPassword || !newPassword || !confirmPassword) {
        alert('Please fill all fields');
        return;
    }
    
    if (newPassword !== confirmPassword) {
        alert('New passwords do not match');
        return;
    }
    
    if (newPassword.length < 8) {
        alert('New password must be at least 8 characters long');
        return;
    }
    
    // In real app, verify current password with backend
    // For demo, we'll just show success
    
    alert('Password changed successfully!');
    closePasswordModal();
}

function deleteAccount() {
    if (confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
        if (confirm('This will delete all your data permanently. Type DELETE to confirm:')) {
            // In real app, this would make API call to delete account
            alert('Account deletion request submitted. You will be logged out.');
            
            // Logout user
            localStorage.removeItem('studentUser');
            localStorage.removeItem('students');
            window.location.href = '../login.html';
        }
    }
}

function exportData() {
    const userData = {
        profile: profileData,
        activities: {
            lastLogin: new Date().toISOString(),
            notesDownloaded: profileData.notesDownloaded,
            videosWatched: profileData.videoWatched
        },
        exportDate: new Date().toISOString()
    };
    
    const dataStr = JSON.stringify(userData, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `BEU_Profile_Data_${profileData.rollno}_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    alert('Profile data exported successfully!');
}