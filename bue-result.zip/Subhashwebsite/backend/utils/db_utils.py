from app import db
from datetime import datetime, timedelta
import json

def seed_database():
    """Seed database with initial data"""
    from models.user import User
    from models.result import Result
    from models.material import Material
    from models.notice import Notice
    
    print("Seeding database...")
    
    # Check if already seeded
    if User.query.count() > 1:  # More than admin
        print("Database already seeded")
        return
    
    # Create sample students
    sample_students = [
        {
            'name': 'Amit Kumar',
            'email': 'amit.kumar@beu.edu.in',
            'password': 'password123',
            'roll_no': 'BEU2024001',
            'branch': 'cse',
            'semester': '5',
            'phone': '+91 9876543210',
            'dob': datetime(2002, 3, 15).date(),
            'gender': 'male',
            'address': 'Patna, Bihar'
        },
        {
            'name': 'Priya Singh',
            'email': 'priya.singh@beu.edu.in',
            'password': 'password123',
            'roll_no': 'BEU2024002',
            'branch': 'ece',
            'semester': '5',
            'phone': '+91 9876543211',
            'dob': datetime(2002, 7, 22).date(),
            'gender': 'female',
            'address': 'Gaya, Bihar'
        }
    ]
    
    for student_data in sample_students:
        student = User(**student_data)
        db.session.add(student)
    
    db.session.commit()
    print(f"Added {len(sample_students)} sample students")
    
    # Add sample results for Amit
    amit = User.query.filter_by(roll_no='BEU2024001').first()
    if amit:
        sample_results = [
            {
                'student_id': amit.id,
                'semester': '5',
                'exam_type': 'regular',
                'exam_year': '2024',
                'subject_code': 'CSE301',
                'subject_name': 'Data Structures',
                'internal_marks': 28,
                'external_marks': 52,
                'total_marks': 80,
                'grade': 'A',
                'status': 'PASS',
                'sgpa': 8.42,
                'percentage': 78.5,
                'result_status': 'PASS',
                'published_by': 'Exam Controller'
            },
            {
                'student_id': amit.id,
                'semester': '5',
                'exam_type': 'regular',
                'exam_year': '2024',
                'subject_code': 'CSE302',
                'subject_name': 'Database Management',
                'internal_marks': 26,
                'external_marks': 48,
                'total_marks': 74,
                'grade': 'B+',
                'status': 'PASS',
                'sgpa': 8.42,
                'percentage': 78.5,
                'result_status': 'PASS',
                'published_by': 'Exam Controller'
            }
        ]
        
        for result_data in sample_results:
            result = Result(**result_data)
            db.session.add(result)
        
        db.session.commit()
        print(f"Added {len(sample_results)} sample results")
    
    # Add sample materials
    sample_materials = [
        {
            'title': 'Data Structures Complete Notes',
            'description': 'Complete notes covering Arrays, Linked Lists, Trees, Graphs',
            'subject': 'Data Structures',
            'subject_code': 'CSE301',
            'branch': 'cse',
            'semester': '5',
            'material_type': 'note',
            'file_url': 'uploads/notes/ds_notes.pdf',
            'file_size': '4.2 MB',
            'author': 'Dr. R. Kumar',
            'is_featured': True,
            'tags': 'ds,algorithms,programming'
        },
        {
            'title': 'DBMS Normalization Tutorial',
            'description': 'Understanding normalization forms with examples',
            'subject': 'Database Management',
            'subject_code': 'CSE302',
            'branch': 'cse',
            'semester': '5',
            'material_type': 'note',
            'file_url': 'uploads/notes/dbms_notes.pdf',
            'file_size': '3.8 MB',
            'author': 'Dr. S. Singh',
            'is_featured': False,
            'tags': 'database,sql,normalization'
        }
    ]
    
    for material_data in sample_materials:
        material = Material(**material_data)
        db.session.add(material)
    
    db.session.commit()
    print(f"Added {len(sample_materials)} sample materials")
    
    # Add sample notices
    sample_notices = [
        {
            'title': 'BEU Odd Semester Results Declared',
            'content': 'The results for BEU Odd Semester 2024 have been declared. Check your results using roll number.',
            'category': 'exam',
            'priority': 'urgent',
            'author': 'Exam Controller',
            'author_role': 'Exam Department',
            'publish_date': datetime.utcnow(),
            'valid_until': datetime.utcnow() + timedelta(days=30)
        },
        {
            'title': 'Summer Vacation Schedule',
            'content': 'College will remain closed from 1st June to 15th July 2024 for summer vacation.',
            'category': 'academic',
            'priority': 'normal',
            'author': 'Registrar Office',
            'author_role': 'Administration',
            'publish_date': datetime.utcnow() - timedelta(days=5),
            'valid_until': datetime.utcnow() + timedelta(days=60)
        }
    ]
    
    for notice_data in sample_notices:
        notice = Notice(**notice_data)
        db.session.add(notice)
    
    db.session.commit()
    print(f"Added {len(sample_notices)} sample notices")
    
    print("Database seeding completed!")

def backup_database():
    """Create database backup"""
    try:
        from sqlalchemy import create_engine
        import sqlite3
        
        # Create backup file name with timestamp
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_file = f'portal_backup_{timestamp}.db'
        
        # Connect to database
        conn = sqlite3.connect('instance/portal.db')
        
        # Create backup connection
        backup_conn = sqlite3.connect(f'instance/backups/{backup_file}')
        
        # Backup database
        conn.backup(backup_conn)
        
        # Close connections
        backup_conn.close()
        conn.close()
        
        print(f"Database backup created: {backup_file}")
        return backup_file
        
    except Exception as e:
        print(f"Backup failed: {e}")
        return None

def export_to_json():
    """Export database to JSON files"""
    try:
        from models.user import User
        from models.result import Result
        from models.material import Material
        from models.notice import Notice
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        # Export users
        users = User.query.all()
        users_data = [user.to_dict() for user in users]
        with open(f'exports/users_{timestamp}.json', 'w') as f:
            json.dump(users_data, f, indent=2)
        
        # Export results
        results = Result.query.all()
        results_data = [result.to_dict() for result in results]
        with open(f'exports/results_{timestamp}.json', 'w') as f:
            json.dump(results_data, f, indent=2)
        
        print(f"Database exported to JSON files")
        
    except Exception as e:
        print(f"Export failed: {e}")