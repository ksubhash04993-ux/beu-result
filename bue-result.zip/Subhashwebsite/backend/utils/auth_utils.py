import re
from datetime import datetime
from functools import wraps
from flask import request, jsonify
from flask_jwt_extended import verify_jwt_in_request, get_jwt_identity
from models.user import User

def validate_email(email):
    """Validate email format"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_password(password):
    """Validate password strength"""
    if len(password) < 8:
        return False, "Password must be at least 8 characters long"
    
    if not re.search(r'[A-Z]', password):
        return False, "Password must contain at least one uppercase letter"
    
    if not re.search(r'[a-z]', password):
        return False, "Password must contain at least one lowercase letter"
    
    if not re.search(r'[0-9]', password):
        return False, "Password must contain at least one number"
    
    return True, "Password is strong"

def validate_roll_no(roll_no):
    """Validate BEU roll number format"""
    pattern = r'^BEU\d{7}$|^\d{2}[A-Z]{3}\d{4,5}$'
    return re.match(pattern, roll_no) is not None

def student_required(fn):
    """Decorator to require student role"""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        verify_jwt_in_request()
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user or user.role != 'student':
            return jsonify({
                'success': False,
                'message': 'Student access required'
            }), 403
        
        return fn(*args, **kwargs)
    return wrapper

def admin_required(fn):
    """Decorator to require admin role"""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        verify_jwt_in_request()
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user or user.role != 'admin':
            return jsonify({
                'success': False,
                'message': 'Admin access required'
            }), 403
        
        return fn(*args, **kwargs)
    return wrapper

def teacher_required(fn):
    """Decorator to require teacher role"""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        verify_jwt_in_request()
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user or user.role != 'teacher':
            return jsonify({
                'success': False,
                'message': 'Teacher access required'
            }), 403
        
        return fn(*args, **kwargs)
    return wrapper

def generate_student_stats(user_id):
    """Generate student dashboard statistics"""
    from models.result import Result
    from models.material import Material
    from models.notice import Notice
    
    # Get results
    results = Result.query.filter_by(student_id=user_id).all()
    
    # Get download stats
    notes_downloaded = Material.query.filter(
        Material.download_count > 0
    ).count()
    
    # Get unread notices
    unread_notices = Notice.query.filter_by(is_read=False).count()
    
    # Calculate average percentage
    if results:
        percentages = [r.percentage for r in results if r.percentage]
        avg_percentage = sum(percentages) / len(percentages) if percentages else 0
    else:
        avg_percentage = 0
    
    return {
        'total_results': len(results),
        'notes_downloaded': notes_downloaded,
        'unread_notices': unread_notices,
        'average_percentage': round(avg_percentage, 2),
        'current_semester': '5th',
        'upcoming_exams': 3
    }