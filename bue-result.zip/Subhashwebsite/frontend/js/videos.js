// Videos Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    const user = localStorage.getItem('studentUser');
    if (!user) {
        window.location.href = '../login.html';
        return;
    }
    
    const userData = JSON.parse(user);
    
    // Set user info
    document.getElementById('studentName').textContent = userData.name || 'Student';
    document.getElementById('studentRoll').textContent = `Roll No: ${userData.rollno || 'N/A'}`;
    
    // Time update
    function updateTime() {
        const now = new Date();
        const timeStr = now.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit',
            hour12: true 
        });
        document.getElementById('currentTime').textContent = timeStr;
    }
    updateTime();
    setInterval(updateTime, 60000);
    
    // Logout functionality
    document.getElementById('logoutBtn').addEventListener('click', function(e) {
        e.preventDefault();
        if (confirm('Are you sure you want to logout?')) {
            localStorage.removeItem('studentUser');
            window.location.href = '../login.html';
        }
    });
    
    // Load videos
    loadVideos('all');
    loadPlaylist();
});

// Sample videos data
const videosData = [
    {
        id: 1,
        title: "Data Structures - Arrays & Linked Lists",
        description: "Complete tutorial on Arrays and Linked Lists with implementation examples.",
        subject: "ds",
        duration: "45:30",
        views: "125,450",
        channel: "CSE Department",
        uploaded: "2 months ago",
        youtubeId: "RBSGKlAvoiM",
        tags: ["Arrays", "Linked Lists", "C++"]
    },
    {
        id: 2,
        title: "DBMS - Normalization Forms",
        description: "Understanding 1NF, 2NF, 3NF and BCNF with practical examples.",
        subject: "dbms",
        duration: "38:15",
        views: "98,765",
        channel: "Prof. S. Singh",
        uploaded: "1 month ago",
        youtubeId: "q4CuB9dD_tc",
        tags: ["Normalization", "Database", "SQL"]
    },
    {
        id: 3,
        title: "OS - Process Scheduling Algorithms",
        description: "Detailed explanation of FCFS, SJF, Priority and Round Robin scheduling.",
        subject: "os",
        duration: "52:45",
        views: "87,432",
        channel: "OS Tutorials",
        uploaded: "3 weeks ago",
        youtubeId: "ekkITCg8hFo",
        tags: ["Scheduling", "Algorithms", "OS Basics"]
    },
    {
        id: 4,
        title: "Computer Networks - OSI Model",
        description: "Complete guide to OSI 7-layer model with real-world examples.",
        subject: "cn",
        duration: "41:20",
        views: "76,543",
        channel: "Network Guru",
        uploaded: "2 weeks ago",
        youtubeId: "vv4y_uOneC0",
        tags: ["OSI Model", "Networking", "Protocols"]
    },
    {
        id: 5,
        title: "TOC - Finite Automata",
        description: "Introduction to DFA, NFA and their applications in computation.",
        subject: "toc",
        duration: "36:55",
        views: "54,321",
        channel: "Theory Lectures",
        uploaded: "1 week ago",
        youtubeId: "wXqK7YK28cM",
        tags: ["Automata", "DFA", "NFA"]
    },
    {
        id: 6,
        title: "Data Structures - Trees & Graphs",
        description: "Binary Trees, BST, AVL Trees and Graph traversal algorithms.",
        subject: "ds",
        duration: "58:10",
        views: "112,345",
        channel: "CSE Department",
        uploaded: "1 month ago",
        youtubeId: "tT10Q8tMp0w",
        tags: ["Trees", "Graphs", "Traversal"]
    },
    {
        id: 7,
        title: "DBMS - SQL Queries Tutorial",
        description: "Learn SELECT, JOIN, GROUP BY and other SQL operations.",
        subject: "dbms",
        duration: "47:25",
        views: "89,012",
        channel: "Prof. S. Singh",
        uploaded: "3 weeks ago",
        youtubeId: "HXV3zeQKqGY",
        tags: ["SQL", "Queries", "Database"]
    },
    {
        id: 8,
        title: "OS - Memory Management",
        description: "Paging, Segmentation and Virtual Memory concepts.",
        subject: "os",
        duration: "44:35",
        views: "67,890",
        channel: "OS Tutorials",
        uploaded: "2 weeks ago",
        youtubeId: "qDKQ4WO7u6Y",
        tags: ["Memory", "Paging", "Virtual Memory"]
    }
];

function loadVideos(category) {
    const filteredVideos = category === 'all' 
        ? videosData 
        : videosData.filter(video => video.subject === category);
    
    const videosGrid = document.getElementById('videosGrid');
    videosGrid.innerHTML = '';
    
    // Update active tab
    document.querySelectorAll('.category-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    event?.target.classList.add('active');
    
    filteredVideos.forEach(video => {
        const videoCard = document.createElement('div');
        videoCard.className = 'video-card';
        videoCard.innerHTML = `
            <div class="video-thumbnail">
                <img src="https://img.youtube.com/vi/${video.youtubeId}/hqdefault.jpg" alt="${video.title}">
                <div class="video-play-btn" onclick="playVideo('${video.youtubeId}', ${video.id})">
                    <i class="fas fa-play"></i>
                </div>
                <div class="video-duration">${video.duration}</div>
            </div>
            <div class="video-info">
                <h4 class="video-title">${video.title}</h4>
                <div class="video-meta-small">
                    <span class="video-channel">
                        <i class="fas fa-user-circle"></i> ${video.channel}
                    </span>
                    <span class="video-stats">
                        <i class="fas fa-eye"></i> ${video.views}
                    </span>
                </div>
                <p class="video-description-small">${video.description}</p>
                <div class="video-tags">
                    ${video.tags.map(tag => `<span class="video-tag">${tag}</span>`).join('')}
                </div>
                <div class="video-actions-small">
                    <button class="btn-watch" onclick="playVideo('${video.youtubeId}', ${video.id})">
                        <i class="fas fa-play"></i> Watch Now
                    </button>
                    <button class="btn-add" onclick="addToPlaylist(${video.id})">
                        <i class="fas fa-plus"></i> Add to Playlist
                    </button>
                </div>
            </div>
        `;
        videosGrid.appendChild(videoCard);
    });
}

function filterVideos(category) {
    loadVideos(category);
}

function playVideo(youtubeId, videoId) {
    const video = videosData.find(v => v.id === videoId);
    
    // Update modal content
    document.getElementById('modalVideoTitle').textContent = video.title;
    
    const videoPlayerHTML = `
        <iframe 
            src="https://www.youtube.com/embed/${youtubeId}?autoplay=1" 
            frameborder="0" 
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
            allowfullscreen>
        </iframe>
    `;
    
    const videoInfoHTML = `
        <h4>${video.title}</h4>
        <div class="modal-video-meta">
            <span><i class="fas fa-user-circle"></i> ${video.channel}</span>
            <span><i class="fas fa-eye"></i> ${video.views} views</span>
            <span><i class="fas fa-clock"></i> ${video.duration}</span>
        </div>
        <p class="modal-video-description">${video.description}</p>
        <div class="modal-video-tags">
            ${video.tags.map(tag => `<span class="video-tag">${tag}</span>`).join('')}
        </div>
    `;
    
    document.getElementById('modalVideoPlayer').innerHTML = videoPlayerHTML;
    document.getElementById('modalVideoInfo').innerHTML = videoInfoHTML;
    
    // Show modal
    document.getElementById('videoModal').classList.add('active');
    
    // Add to watch history
    addToHistory(videoId);
}

function closeVideoModal() {
    document.getElementById('videoModal').classList.remove('active');
    // Stop video
    document.getElementById('modalVideoPlayer').innerHTML = '';
}

function addToPlaylist(videoId) {
    const playlist = JSON.parse(localStorage.getItem('videoPlaylist') || '[]');
    
    // Check if already in playlist
    if (playlist.some(item => item.videoId === videoId)) {
        alert('Video already in playlist!');
        return;
    }
    
    const video = videosData.find(v => v.id === videoId);
    if (!video) return;
    
    playlist.push({
        videoId: video.id,
        title: video.title,
        channel: video.channel,
        duration: video.duration,
        youtubeId: video.youtubeId,
        addedAt: new Date().toISOString()
    });
    
    localStorage.setItem('videoPlaylist', JSON.stringify(playlist));
    loadPlaylist();
    
    alert('Video added to playlist!');
}

function loadPlaylist() {
    const playlist = JSON.parse(localStorage.getItem('videoPlaylist') || '[]');
    const playlistContainer = document.getElementById('playlistContainer');
    
    if (playlist.length === 0) {
        playlistContainer.innerHTML = `
            <div class="playlist-empty">
                <i class="fas fa-list"></i>
                <h4>Your playlist is empty</h4>
                <p>Add videos to watch later</p>
            </div>
        `;
        return;
    }
    
    playlistContainer.innerHTML = '';
    
    playlist.forEach((item, index) => {
        const playlistItem = document.createElement('div');
        playlistItem.className = 'playlist-item';
        playlistItem.innerHTML = `
            <div class="playlist-thumb">
                <img src="https://img.youtube.com/vi/${item.youtubeId}/hqdefault.jpg" alt="${item.title}">
            </div>
            <div class="playlist-info">
                <h5>${item.title}</h5>
                <p>
                    <span><i class="fas fa-user-circle"></i> ${item.channel}</span>
                    <span><i class="fas fa-clock"></i> ${item.duration}</span>
                </p>
            </div>
            <div class="playlist-actions">
                <button class="btn-play-now" onclick="playVideo('${item.youtubeId}', ${item.videoId})">
                    <i class="fas fa-play"></i> Play
                </button>
                <button class="btn-remove" onclick="removeFromPlaylist(${index})">
                    <i class="fas fa-trash"></i> Remove
                </button>
            </div>
        `;
        playlistContainer.appendChild(playlistItem);
    });
}

function removeFromPlaylist(index) {
    const playlist = JSON.parse(localStorage.getItem('videoPlaylist') || '[]');
    playlist.splice(index, 1);
    localStorage.setItem('videoPlaylist', JSON.stringify(playlist));
    loadPlaylist();
}

function clearPlaylist() {
    if (confirm('Are you sure you want to clear your playlist?')) {
        localStorage.removeItem('videoPlaylist');
        loadPlaylist();
    }
}

function addToHistory(videoId) {
    const history = JSON.parse(localStorage.getItem('videoHistory') || '[]');
    const video = videosData.find(v => v.id === videoId);
    
    if (!video) return;
    
    // Remove if already exists
    const existingIndex = history.findIndex(item => item.videoId === videoId);
    if (existingIndex > -1) {
        history.splice(existingIndex, 1);
    }
    
    // Add to beginning
    history.unshift({
        videoId: video.id,
        title: video.title,
        watchedAt: new Date().toISOString()
    });
    
    // Keep only last 20
    if (history.length > 20) {
        history.pop();
    }
    
    localStorage.setItem('videoHistory', JSON.stringify(history));
}

function shareVideo() {
    const videoUrl = window.location.href;
    
    if (navigator.share) {
        navigator.share({
            title: 'BEU Video Lecture',
            text: 'Check out this educational video from BEU College Portal',
            url: videoUrl
        });
    } else {
        // Fallback for browsers that don't support Web Share API
        navigator.clipboard.writeText(videoUrl).then(() => {
            alert('Link copied to clipboard!');
        });
    }
}