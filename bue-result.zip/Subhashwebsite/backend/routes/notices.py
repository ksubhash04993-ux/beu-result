from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app import db
from models.notice import Notice
from models.user import User
from utils.auth_utils import admin_required, teacher_required
from utils.file_utils import save_uploaded_file, delete_file
from datetime import datetime

notices_bp = Blueprint('notices', __name__)

@notices_bp.route('/', methods=['GET'])
@jwt_required()
def get_all_notices():
    """Get all notices with filters (admin/teacher get all, students get filtered)"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        # Get filters
        category = request.args.get('category')
        priority = request.args.get('priority')
        search = request.args.get('search')
        limit = request.args.get('limit', 20, type=int)
        page = request.args.get('page', 1, type=int)
        
        # Build query
        query = Notice.query
        
        # For students, show only published notices
        if user.role == 'student':
            query = query.filter_by(is_published=True)
        
        if category and category != 'all':
            query = query.filter_by(category=category)
        
        if priority and priority != 'all':
            query = query.filter_by(priority=priority)
        
        if search:
            query = query.filter(
                (Notice.title.ilike(f'%{search}%')) |
                (Notice.content.ilike(f'%{search}%')) |
                (Notice.author.ilike(f'%{search}%'))
            )
        
        # Filter by branch/semester for students
        if user.role == 'student':
            query = query.filter(
                (Notice.target_branch == None) | (Notice.target_branch == user.branch)
            )
            query = query.filter(
                (Notice.target_semester == None) | (Notice.target_semester == user.semester)
            )
        
        # Pagination
        total = query.count()
        notices = query.order_by(Notice.publish_date.desc())\
            .offset((page - 1) * limit)\
            .limit(limit)\
            .all()
        
        return jsonify({
            'success': True,
            'notices': [notice.to_dict() for notice in notices],
            'total': total,
            'page': page,
            'pages': (total + limit - 1) // limit
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Failed to fetch notices',
            'error': str(e)
        }), 500

@notices_bp.route('/<int:notice_id>', methods=['GET'])
@jwt_required()
def get_notice(notice_id):
    """Get specific notice"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        notice = Notice.query.get(notice_id)
        
        if not notice:
            return jsonify({
                'success': False,
                'message': 'Notice not found'
            }), 404
        
        # Check if student can view this notice
        if user.role == 'student' and not notice.is_published:
            return jsonify({
                'success': False,
                'message': 'Notice not published'
            }), 403
        
        # Check branch/semester restrictions for students
        if user.role == 'student':
            if notice.target_branch and notice.target_branch != user.branch:
                return jsonify({
                    'success': False,
                    'message': 'Notice not available for your branch'
                }), 403
            
            if notice.target_semester and notice.target_semester != user.semester:
                return jsonify({
                    'success': False,
                    'message': 'Notice not available for your semester'
                }), 403
        
        # Increment view count
        notice.increment_view()
        
        return jsonify({
            'success': True,
            'notice': notice.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Failed to fetch notice',
            'error': str(e)
        }), 500

@notices_bp.route('/', methods=['POST'])
@jwt_required()
@admin_required
def create_notice():
    """Create new notice (admin only)"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['title', 'content', 'category']
        for field in required_fields:
            if not data.get(field):
                return jsonify({
                    'success': False,
                    'message': f'{field} is required'
                }), 400
        
        # Create notice
        notice = Notice(
            title=data['title'],
            content=data['content'],
            category=data['category'],
            priority=data.get('priority', 'normal'),
            author=user.name,
            author_role=user.role,
            target_branch=data.get('target_branch'),
            target_semester=data.get('target_semester'),
            is_published=data.get('is_published', True)
        )
        
        # Handle valid until date
        if data.get('valid_until'):
            notice.valid_until = datetime.fromisoformat(data['valid_until'])
        
        # Handle attachment if provided
        if 'attachment_url' in data:
            notice.attachment_url = data['attachment_url']
            notice.attachment_name = data.get('attachment_name', 'attachment')
        
        db.session.add(notice)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Notice created successfully',
            'notice': notice.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': 'Failed to create notice',
            'error': str(e)
        }), 500

@notices_bp.route('/<int:notice_id>', methods=['PUT'])
@jwt_required()
@admin_required
def update_notice(notice_id):
    """Update notice (admin only)"""
    try:
        notice = Notice.query.get(notice_id)
        
        if not notice:
            return jsonify({
                'success': False,
                'message': 'Notice not found'
            }), 404
        
        data = request.get_json()
        
        # Update fields
        updatable_fields = [
            'title', 'content', 'category', 'priority',
            'target_branch', 'target_semester', 'is_published'
        ]
        
        for field in updatable_fields:
            if field in data:
                setattr(notice, field, data[field])
        
        # Handle valid until date
        if 'valid_until' in data:
            if data['valid_until']:
                notice.valid_until = datetime.fromisoformat(data['valid_until'])
            else:
                notice.valid_until = None
        
        # Handle attachment
        if 'attachment_url' in data:
            # Delete old attachment if exists
            if notice.attachment_url:
                delete_file(notice.attachment_url)
            
            notice.attachment_url = data['attachment_url']
            notice.attachment_name = data.get('attachment_name', 'attachment')
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Notice updated successfully',
            'notice': notice.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': 'Failed to update notice',
            'error': str(e)
        }), 500

@notices_bp.route('/<int:notice_id>', methods=['DELETE'])
@jwt_required()
@admin_required
def delete_notice(notice_id):
    """Delete notice (admin only)"""
    try:
        notice = Notice.query.get(notice_id)
        
        if not notice:
            return jsonify({
                'success': False,
                'message': 'Notice not found'
            }), 404
        
        # Delete attachment if exists
        if notice.attachment_url:
            delete_file(notice.attachment_url)
        
        db.session.delete(notice)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Notice deleted successfully'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': 'Failed to delete notice',
            'error': str(e)
        }), 500

@notices_bp.route('/categories', methods=['GET'])
def get_categories():
    """Get notice categories"""
    categories = [
        {'value': 'exam', 'label': 'Exam Notices'},
        {'value': 'academic', 'label': 'Academic'},
        {'value': 'event', 'label': 'Events'},
        {'value': 'general', 'label': 'General'},
        {'value': 'urgent', 'label': 'Urgent'}
    ]
    
    return jsonify({
        'success': True,
        'categories': categories
    }), 200

@notices_bp.route('/stats', methods=['GET'])
@jwt_required()
@admin_required
def get_notice_stats():
    """Get notice statistics (admin only)"""
    try:
        total_notices = Notice.query.count()
        published_notices = Notice.query.filter_by(is_published=True).count()
        urgent_notices = Notice.query.filter_by(priority='urgent').count()
        
        # Notices by category
        categories = ['exam', 'academic', 'event', 'general']
        category_stats = {}
        
        for category in categories:
            count = Notice.query.filter_by(category=category).count()
            category_stats[category] = count
        
        return jsonify({
            'success': True,
            'stats': {
                'total': total_notices,
                'published': published_notices,
                'urgent': urgent_notices,
                'categories': category_stats
            }
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Failed to fetch notice stats',
            'error': str(e)
        }), 500

@notices_bp.route('/upload-attachment', methods=['POST'])
@jwt_required()
@admin_required
def upload_attachment():
    """Upload notice attachment (admin only)"""
    try:
        if 'file' not in request.files:
            return jsonify({
                'success': False,
                'message': 'No file uploaded'
            }), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({
                'success': False,
                'message': 'No file selected'
            }), 400
        
        # Save file
        file_url = save_uploaded_file(file, 'notices')
        
        if not file_url:
            return jsonify({
                'success': False,
                'message': 'Invalid file type'
            }), 400
        
        return jsonify({
            'success': True,
            'message': 'Attachment uploaded successfully',
            'file_url': file_url,
            'file_name': file.filename
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Upload failed',
            'error': str(e)
        }), 500