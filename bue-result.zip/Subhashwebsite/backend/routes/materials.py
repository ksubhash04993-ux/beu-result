from flask import Blueprint, request, jsonify, send_file
from flask_jwt_extended import jwt_required, get_jwt_identity
from app import db
from models.material import Material
from models.user import User
from utils.auth_utils import student_required
from utils.file_utils import save_uploaded_file, get_file_size
import os

materials_bp = Blueprint('materials', __name__)

@materials_bp.route('/notes', methods=['GET'])
@jwt_required()
@student_required
def get_notes():
    """Get study notes with filters"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        # Get filters
        branch = request.args.get('branch', user.branch)
        semester = request.args.get('semester', user.semester)
        subject = request.args.get('subject')
        search = request.args.get('search')
        
        # Build query
        query = Material.query.filter_by(
            material_type='note',
            branch=branch,
            semester=semester,
            is_approved=True
        )
        
        if subject and subject != 'all':
            query = query.filter_by(subject_code=subject)
        
        if search:
            query = query.filter(
                (Material.title.ilike(f'%{search}%')) |
                (Material.description.ilike(f'%{search}%')) |
                (Material.subject.ilike(f'%{search}%'))
            )
        
        # Execute query
        notes = query.order_by(Material.uploaded_at.desc()).all()
        
        return jsonify({
            'success': True,
            'notes': [note.to_dict() for note in notes],
            'total': len(notes)
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Failed to fetch notes',
            'error': str(e)
        }), 500

@materials_bp.route('/notes/<int:note_id>', methods=['GET'])
@jwt_required()
@student_required
def get_note(note_id):
    """Get specific note details"""
    try:
        note = Material.query.get(note_id)
        
        if not note or note.material_type != 'note' or not note.is_approved:
            return jsonify({
                'success': False,
                'message': 'Note not found'
            }), 404
        
        return jsonify({
            'success': True,
            'note': note.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Failed to fetch note',
            'error': str(e)
        }), 500

@materials_bp.route('/notes/<int:note_id>/download', methods=['POST'])
@jwt_required()
@student_required
def download_note(note_id):
    """Download note and increment download count"""
    try:
        note = Material.query.get(note_id)
        
        if not note or note.material_type != 'note':
            return jsonify({
                'success': False,
                'message': 'Note not found'
            }), 404
        
        # Increment download count
        note.increment_download()
        
        # Return file path
        return jsonify({
            'success': True,
            'message': 'Note download registered',
            'download_url': f"/api/materials/files/{note.file_url}",
            'note': note.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Download failed',
            'error': str(e)
        }), 500

@materials_bp.route('/videos', methods=['GET'])
@jwt_required()
@student_required
def get_videos():
    """Get video lectures with filters"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        # Get filters
        branch = request.args.get('branch', user.branch)
        semester = request.args.get('semester', user.semester)
        subject = request.args.get('subject')
        search = request.args.get('search')
        
        # Build query
        query = Material.query.filter_by(
            material_type='video',
            branch=branch,
            semester=semester,
            is_approved=True
        )
        
        if subject and subject != 'all':
            query = query.filter_by(subject_code=subject)
        
        if search:
            query = query.filter(
                (Material.title.ilike(f'%{search}%')) |
                (Material.description.ilike(f'%{search}%')) |
                (Material.subject.ilike(f'%{search}%'))
            )
        
        # Execute query
        videos = query.order_by(Material.uploaded_at.desc()).all()
        
        return jsonify({
            'success': True,
            'videos': [video.to_dict() for video in videos],
            'total': len(videos)
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Failed to fetch videos',
            'error': str(e)
        }), 500

@materials_bp.route('/videos/<int:video_id>', methods=['GET'])
@jwt_required()
@student_required
def get_video(video_id):
    """Get specific video details"""
    try:
        video = Material.query.get(video_id)
        
        if not video or video.material_type != 'video' or not video.is_approved:
            return jsonify({
                'success': False,
                'message': 'Video not found'
            }), 404
        
        # Increment view count
        video.increment_view()
        
        return jsonify({
            'success': True,
            'video': video.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Failed to fetch video',
            'error': str(e)
        }), 500

@materials_bp.route('/subjects', methods=['GET'])
@jwt_required()
@student_required
def get_subjects():
    """Get available subjects for student's branch and semester"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        # Sample subjects based on branch
        subjects_by_branch = {
            'cse': [
                {'code': 'CSE301', 'name': 'Data Structures'},
                {'code': 'CSE302', 'name': 'Database Management'},
                {'code': 'CSE303', 'name': 'Operating Systems'},
                {'code': 'CSE304', 'name': 'Computer Networks'},
                {'code': 'CSE305', 'name': 'Theory of Computation'},
                {'code': 'MATH301', 'name': 'Discrete Mathematics'}
            ],
            'ece': [
                {'code': 'ECE301', 'name': 'Digital Electronics'},
                {'code': 'ECE302', 'name': 'Signals & Systems'},
                {'code': 'ECE303', 'name': 'Communication Systems'},
                {'code': 'ECE304', 'name': 'Microprocessors'},
                {'code': 'ECE305', 'name': 'Electromagnetic Theory'}
            ],
            'me': [
                {'code': 'ME301', 'name': 'Thermodynamics'},
                {'code': 'ME302', 'name': 'Mechanics of Materials'},
                {'code': 'ME303', 'name': 'Fluid Mechanics'},
                {'code': 'ME304', 'name': 'Machine Design'},
                {'code': 'ME305', 'name': 'Heat Transfer'}
            ]
        }
        
        subjects = subjects_by_branch.get(user.branch, [])
        
        return jsonify({
            'success': True,
            'subjects': subjects
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Failed to fetch subjects',
            'error': str(e)
        }), 500

@materials_bp.route('/recent', methods=['GET'])
@jwt_required()
@student_required
def get_recent_materials():
    """Get recently accessed/downloaded materials"""
    try:
        user_id = get_jwt_identity()
        
        # Get recent notes (most downloaded)
        recent_notes = Material.query.filter_by(
            material_type='note',
            is_approved=True
        ).order_by(Material.download_count.desc()).limit(5).all()
        
        # Get recent videos (most viewed)
        recent_videos = Material.query.filter_by(
            material_type='video',
            is_approved=True
        ).order_by(Material.view_count.desc()).limit(5).all()
        
        return jsonify({
            'success': True,
            'recent_notes': [note.to_dict() for note in recent_notes],
            'recent_videos': [video.to_dict() for video in recent_videos]
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Failed to fetch recent materials',
            'error': str(e)
        }), 500

@materials_bp.route('/files/<path:filepath>', methods=['GET'])
def serve_file(filepath):
    """Serve uploaded files"""
    try:
        # Security check - prevent directory traversal
        if '..' in filepath or filepath.startswith('/'):
            return jsonify({
                'success': False,
                'message': 'Invalid file path'
            }), 400
        
        # Build full path
        full_path = os.path.join('static', filepath)
        
        if not os.path.exists(full_path):
            return jsonify({
                'success': False,
                'message': 'File not found'
            }), 404
        
        return send_file(full_path, as_attachment=True)
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Failed to serve file',
            'error': str(e)
        }), 500

@materials_bp.route('/upload', methods=['POST'])
@jwt_required()
def upload_material():
    """Upload study material (admin/teacher only)"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        # Check permissions
        if user.role not in ['admin', 'teacher']:
            return jsonify({
                'success': False,
                'message': 'Permission denied'
            }), 403
        
        # Get form data
        title = request.form.get('title')
        description = request.form.get('description')
        subject = request.form.get('subject')
        subject_code = request.form.get('subject_code')
        branch = request.form.get('branch')
        semester = request.form.get('semester')
        material_type = request.form.get('material_type')  # note or video
        author = request.form.get('author')
        tags = request.form.get('tags')
        
        # Validate required fields
        if not all([title, subject, subject_code, branch, semester, material_type]):
            return jsonify({
                'success': False,
                'message': 'Missing required fields'
            }), 400
        
        # Handle file upload
        if 'file' not in request.files:
            return jsonify({
                'success': False,
                'message': 'No file uploaded'
            }), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({
                'success': False,
                'message': 'No file selected'
            }), 400
        
        # Save file
        folder = 'notes' if material_type == 'note' else 'videos'
        file_url = save_uploaded_file(file, folder)
        
        if not file_url:
            return jsonify({
                'success': False,
                'message': 'Invalid file type'
            }), 400
        
        # Create material record
        material = Material(
            title=title,
            description=description,
            subject=subject,
            subject_code=subject_code,
            branch=branch,
            semester=semester,
            material_type=material_type,
            file_url=file_url,
            file_size=get_file_size(os.path.join('static', file_url)),
            author=author or user.name,
            uploaded_by=user.id,
            tags=tags,
            is_approved=user.role == 'admin'  # Auto-approve for admin
        )
        
        # For videos, extract thumbnail if provided
        if material_type == 'video' and 'thumbnail' in request.files:
            thumbnail = request.files['thumbnail']
            if thumbnail and thumbnail.filename != '':
                thumb_url = save_uploaded_file(thumbnail, 'thumbnails')
                if thumb_url:
                    material.thumbnail_url = thumb_url
        
        db.session.add(material)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Material uploaded successfully',
            'material': material.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': 'Upload failed',
            'error': str(e)
        }), 500