from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from datetime import datetime
import requests
from bs4 import BeautifulSoup
import re

beu_bp = Blueprint('beu', __name__)

class BEUResultFetcher:
    """Main class to handle all BEU result fetching methods"""
    
    @staticmethod
    def fetch_using_scraping(roll_no, semester, exam_year):
        """Method 1: Web Scraping"""
        try:
            # BEU result portal URL (verify current URL)
            result_url = "http://results.beu-bih.ac.in/"
            
            # Prepare form data
            payload = {
                'roll': roll_no,
                'sem': semester,
                'year': exam_year
            }
            
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Referer': result_url
            }
            
            # Make request
            session = requests.Session()
            response = session.post(result_url, data=payload, headers=headers)
            
            if response.status_code == 200:
                return BEUResultFetcher.parse_scraped_result(response.text, roll_no)
            else:
                return None
                
        except Exception as e:
            print(f"Scraping error: {e}")
            return None
    
    @staticmethod
    def parse_scraped_result(html_content, roll_no):
        """Parse scraped HTML result"""
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # Look for result tables
            tables = soup.find_all('table')
            
            if len(tables) < 2:
                return None
            
            # Assuming result is in second table
            result_table = tables[1]
            rows = result_table.find_all('tr')
            
            # Extract data
            result_data = {
                'roll_no': roll_no,
                'subjects': [],
                'student_info': {},
                'overall': {}
            }
            
            # Parse rows (adjust based on actual structure)
            for row in rows:
                cols = [td.text.strip() for td in row.find_all('td')]
                
                if len(cols) >= 6:
                    # Subject row
                    result_data['subjects'].append({
                        'code': cols[0],
                        'name': cols[1],
                        'internal': cols[2],
                        'external': cols[3],
                        'total': cols[4],
                        'grade': cols[5],
                        'status': 'PASS' if int(cols[4]) >= 40 else 'FAIL'
                    })
                elif 'SGPA' in str(row):
                    # Overall result row
                    result_data['overall'] = {
                        'sgpa': cols[1] if len(cols) > 1 else '',
                        'percentage': cols[2] if len(cols) > 2 else '',
                        'result': cols[3] if len(cols) > 3 else ''
                    }
            
            return result_data
            
        except Exception as e:
            print(f"Parse error: {e}")
            return None
    
    @staticmethod
    def fetch_using_telegram(roll_no, semester):
        """Method 2: Telegram bot integration"""
        try:
            # Search in known BEU result channels
            channels = [
                'beuresults',
                'biharengg',
                'beuupdates'
            ]
            
            # This would require Telegram API access
            # For now, return mock data
            return {
                'method': 'telegram',
                'roll_no': roll_no,
                'semester': semester,
                'found': False,
                'message': 'Telegram integration requires API setup'
            }
            
        except Exception as e:
            return None
    
    @staticmethod
    def fetch_using_api(roll_no, semester):
        """Method 3: Third-party API if available"""
        try:
            # Some third-party services provide BEU results
            # Example: https://biharresult.com/api
            api_url = "https://biharresult.com/api/beu"
            
            payload = {
                'rollno': roll_no,
                'sem': semester
            }
            
            response = requests.post(api_url, json=payload, timeout=10)
            
            if response.status_code == 200:
                return response.json()
            else:
                return None
                
        except:
            return None

# API Routes
@beu_bp.route('/check', methods=['POST'])
@jwt_required()
def check_beu_result():
    """Check BEU result using multiple methods"""
    try:
        data = request.get_json()
        
        roll_no = data.get('roll_no')
        semester = data.get('semester')
        exam_year = data.get('exam_year', datetime.now().year)
        
        if not roll_no or not semester:
            return jsonify({
                'success': False,
                'message': 'Roll number and semester required'
            }), 400
        
        # Try Method 1: Scraping
        result = BEUResultFetcher.fetch_using_scraping(roll_no, semester, exam_year)
        
        if result:
            return jsonify({
                'success': True,
                'method': 'web_scraping',
                'data': result,
                'fetched_at': datetime.now().isoformat()
            }), 200
        
        # Try Method 2: Telegram
        telegram_result = BEUResultFetcher.fetch_using_telegram(roll_no, semester)
        
        if telegram_result and telegram_result.get('found'):
            return jsonify({
                'success': True,
                'method': 'telegram',
                'data': telegram_result,
                'fetched_at': datetime.now().isoformat()
            }), 200
        
        # Try Method 3: API
        api_result = BEUResultFetcher.fetch_using_api(roll_no, semester)
        
        if api_result:
            return jsonify({
                'success': True,
                'method': 'third_party_api',
                'data': api_result,
                'fetched_at': datetime.now().isoformat()
            }), 200
        
        # If all methods fail
        return jsonify({
            'success': False,
            'message': 'Result not found. Try checking official BEU website.',
            'official_links': [
                'http://results.beu-bih.ac.in/',
                'https://beu-bih.ac.in/result.php'
            ]
        }), 404
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error: {str(e)}'
        }), 500

@beu_bp.route('/status', methods=['GET'])
def check_result_status():
    """Check if BEU results are declared"""
    try:
        # Check BEU website for result announcements
        beu_url = "https://beu-bih.ac.in"
        
        response = requests.get(beu_url, timeout=10)
        
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Look for result announcements
            announcements = []
            
            # Check for result links
            links = soup.find_all('a', href=True)
            for link in links:
                link_text = link.text.lower()
                if 'result' in link_text:
                    announcements.append({
                        'title': link.text.strip(),
                        'url': link['href'] if link['href'].startswith('http') else f"{beu_url}/{link['href']}"
                    })
            
            # Check for notices
            notices = soup.find_all('div', class_='notice')
            for notice in notices:
                notice_text = notice.text.lower()
                if 'result' in notice_text or 'declared' in notice_text:
                    announcements.append({
                        'title': notice.text.strip()[:100],
                        'type': 'notice'
                    })
            
            return jsonify({
                'success': True,
                'results_declared': len(announcements) > 0,
                'announcements': announcements,
                'last_checked': datetime.now().isoformat()
            }), 200
            
        else:
            return jsonify({
                'success': False,
                'message': 'Cannot connect to BEU website'
            }), 500
            
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error: {str(e)}'
        }), 500

@beu_bp.route('/manual-upload', methods=['POST'])
@jwt_required()
def manual_result_upload():
    """Manual result upload for students"""
    try:
        user_id = get_jwt_identity()
        data = request.get_json()
        
        # Validate data
        required_fields = ['semester', 'subjects', 'overall_result']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'message': f'{field} is required'
                }), 400
        
        # Save to database
        from app import db
        from models.result import Result
        
        # Delete existing results for this semester
        Result.query.filter_by(
            student_id=user_id,
            semester=data['semester']
        ).delete()
        
        # Add new results
        for subject in data['subjects']:
            result = Result(
                student_id=user_id,
                semester=data['semester'],
                exam_type=data.get('exam_type', 'regular'),
                exam_year=data.get('exam_year', datetime.now().year),
                subject_code=subject.get('code'),
                subject_name=subject.get('name'),
                internal_marks=int(subject.get('internal', 0)),
                external_marks=int(subject.get('external', 0)),
                total_marks=int(subject.get('total', 0)),
                grade=subject.get('grade'),
                status=subject.get('status', 'PASS'),
                sgpa=float(data['overall_result'].get('sgpa', 0)),
                percentage=float(data['overall_result'].get('percentage', 0)),
                result_status=data['overall_result'].get('result', 'PASS'),
                published_by='Manual Upload'
            )
            db.session.add(result)
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Result uploaded successfully'
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': f'Upload failed: {str(e)}'
        }), 500

@beu_bp.route('/verify', methods=['POST'])
def verify_result():
    """Verify result authenticity (compare with multiple sources)"""
    try:
        data = request.get_json()
        
        roll_no = data.get('roll_no')
        semester = data.get('semester')
        
        if not roll_no or not semester:
            return jsonify({
                'success': False,
                'message': 'Roll number and semester required'
            }), 400
        
        # Try multiple sources
        sources = []
        
        # Source 1: Web scraping
        scraped = BEUResultFetcher.fetch_using_scraping(roll_no, semester, datetime.now().year)
        if scraped:
            sources.append({
                'method': 'web_scraping',
                'data': scraped,
                'timestamp': datetime.now().isoformat()
            })
        
        # Source 2: Check cached results
        from models.result import Result
        from models.user import User
        
        user = User.query.filter_by(roll_no=roll_no).first()
        if user:
            cached = Result.query.filter_by(student_id=user.id, semester=semester).all()
            if cached:
                sources.append({
                    'method': 'database_cache',
                    'data': [r.to_dict() for r in cached],
                    'timestamp': datetime.now().isoformat()
                })
        
        return jsonify({
            'success': True,
            'sources_checked': len(sources),
            'sources': sources,
            'verification_score': len(sources) * 0.5  # Simple scoring
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Verification failed: {str(e)}'
        }), 500