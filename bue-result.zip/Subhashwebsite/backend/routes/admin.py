from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app import db
from models.user import User
from models.result import Result
from models.material import Material
from models.notice import Notice
from utils.auth_utils import admin_required
from utils.db_utils import seed_database, backup_database, export_to_json
from datetime import datetime, timedelta

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/dashboard', methods=['GET'])
@jwt_required()
@admin_required
def admin_dashboard():
    """Get admin dashboard statistics"""
    try:
        # User statistics
        total_users = User.query.count()
        total_students = User.query.filter_by(role='student').count()
        total_teachers = User.query.filter_by(role='teacher').count()
        active_users = User.query.filter_by(is_active=True).count()
        
        # Material statistics
        total_notes = Material.query.filter_by(material_type='note').count()
        total_videos = Material.query.filter_by(material_type='video').count()
        pending_approvals = Material.query.filter_by(is_approved=False).count()
        
        # Notice statistics
        total_notices = Notice.query.count()
        published_notices = Notice.query.filter_by(is_published=True).count()
        
        # Recent activity
        recent_users = User.query.order_by(User.created_at.desc()).limit(5).all()
        recent_notices = Notice.query.order_by(Notice.publish_date.desc()).limit(5).all()
        
        # System stats
        from sqlalchemy import func
        total_downloads = db.session.query(func.sum(Material.download_count)).scalar() or 0
        total_views = db.session.query(func.sum(Material.view_count)).scalar() or 0
        
        return jsonify({
            'success': True,
            'stats': {
                'users': {
                    'total': total_users,
                    'students': total_students,
                    'teachers': total_teachers,
                    'active': active_users
                },
                'materials': {
                    'notes': total_notes,
                    'videos': total_videos,
                    'pending_approvals': pending_approvals,
                    'total_downloads': total_downloads,
                    'total_views': total_views
                },
                'notices': {
                    'total': total_notices,
                    'published': published_notices
                }
            },
            'recent_users': [user.to_dict() for user in recent_users],
            'recent_notices': [notice.to_dict() for notice in recent_notices]
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Failed to fetch dashboard data',
            'error': str(e)
        }), 500

@admin_bp.route('/users', methods=['GET'])
@jwt_required()
@admin_required
def get_all_users():
    """Get all users with pagination and filters"""
    try:
        # Get filters
        role = request.args.get('role')
        branch = request.args.get('branch')
        search = request.args.get('search')
        limit = request.args.get('limit', 20, type=int)
        page = request.args.get('page', 1, type=int)
        
        # Build query
        query = User.query
        
        if role and role != 'all':
            query = query.filter_by(role=role)
        
        if branch and branch != 'all':
            query = query.filter_by(branch=branch)
        
        if search:
            query = query.filter(
                (User.name.ilike(f'%{search}%')) |
                (User.email.ilike(f'%{search}%')) |
                (User.roll_no.ilike(f'%{search}%'))
            )
        
        # Pagination
        total = query.count()
        users = query.order_by(User.created_at.desc())\
            .offset((page - 1) * limit)\
            .limit(limit)\
            .all()
        
        return jsonify({
            'success': True,
            'users': [user.to_dict() for user in users],
            'total': total,
            'page': page,
            'pages': (total + limit - 1) // limit
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Failed to fetch users',
            'error': str(e)
        }), 500

@admin_bp.route('/users/<int:user_id>', methods=['GET'])
@jwt_required()
@admin_required
def get_user(user_id):
    """Get specific user details"""
    try:
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({
                'success': False,
                'message': 'User not found'
            }), 404
        
        # Get user's results
        results = Result.query.filter_by(student_id=user_id).all()
        
        return jsonify({
            'success': True,
            'user': user.to_dict(),
            'results': [result.to_dict() for result in results],
            'total_results': len(results)
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Failed to fetch user',
            'error': str(e)
        }), 500

@admin_bp.route('/users/<int:user_id>', methods=['PUT'])
@jwt_required()
@admin_required
def update_user(user_id):
    """Update user (admin only)"""
    try:
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({
                'success': False,
                'message': 'User not found'
            }), 404
        
        data = request.get_json()
        
        # Update allowed fields
        allowed_fields = ['name', 'email', 'roll_no', 'branch', 
                         'semester', 'phone', 'role', 'is_active']
        
        for field in allowed_fields:
            if field in data:
                setattr(user, field, data[field])
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'User updated successfully',
            'user': user.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': 'Failed to update user',
            'error': str(e)
        }), 500

@admin_bp.route('/users/<int:user_id>', methods=['DELETE'])
@jwt_required()
@admin_required
def delete_user(user_id):
    """Delete user (admin only)"""
    try:
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({
                'success': False,
                'message': 'User not found'
            }), 404
        
        # Don't allow self-deletion
        current_user_id = get_jwt_identity()
        if user_id == current_user_id:
            return jsonify({
                'success': False,
                'message': 'Cannot delete your own account'
            }), 400
        
        # Don't delete if user has important data
        # In production, you might want to soft delete
        
        db.session.delete(user)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'User deleted successfully'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': 'Failed to delete user',
            'error': str(e)
        }), 500

@admin_bp.route('/materials/pending', methods=['GET'])
@jwt_required()
@admin_required
def get_pending_materials():
    """Get materials pending approval"""
    try:
        materials = Material.query.filter_by(is_approved=False)\
            .order_by(Material.uploaded_at.desc())\
            .all()
        
        return jsonify({
            'success': True,
            'materials': [material.to_dict() for material in materials],
            'total': len(materials)
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Failed to fetch pending materials',
            'error': str(e)
        }), 500

@admin_bp.route('/materials/<int:material_id>/approve', methods=['POST'])
@jwt_required()
@admin_required
def approve_material(material_id):
    """Approve material"""
    try:
        material = Material.query.get(material_id)
        
        if not material:
            return jsonify({
                'success': False,
                'message': 'Material not found'
            }), 404
        
        material.is_approved = True
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Material approved successfully'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': 'Failed to approve material',
            'error': str(e)
        }), 500

@admin_bp.route('/materials/<int:material_id>/feature', methods=['POST'])
@jwt_required()
@admin_required
def toggle_feature_material(material_id):
    """Toggle featured status of material"""
    try:
        material = Material.query.get(material_id)
        
        if not material:
            return jsonify({
                'success': False,
                'message': 'Material not found'
            }), 404
        
        material.is_featured = not material.is_featured
        db.session.commit()
        
        status = 'featured' if material.is_featured else 'unfeatured'
        
        return jsonify({
            'success': True,
            'message': f'Material {status} successfully'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': 'Failed to update material',
            'error': str(e)
        }), 500

@admin_bp.route('/results/upload', methods=['POST'])
@jwt_required()
@admin_required
def upload_results():
    """Upload student results (CSV/Excel)"""
    try:
        if 'file' not in request.files:
            return jsonify({
                'success': False,
                'message': 'No file uploaded'
            }), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({
                'success': False,
                'message': 'No file selected'
            }), 400
        
        # In production, parse CSV/Excel file
        # For now, return success
        return jsonify({
            'success': True,
            'message': 'Results upload endpoint ready',
            'note': 'Implement CSV/Excel parsing logic here'
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Upload failed',
            'error': str(e)
        }), 500

@admin_bp.route('/system/seed', methods=['POST'])
@jwt_required()
@admin_required
def seed_data():
    """Seed database with sample data"""
    try:
        seed_database()
        
        return jsonify({
            'success': True,
            'message': 'Database seeded successfully'
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Seeding failed',
            'error': str(e)
        }), 500

@admin_bp.route('/system/backup', methods=['POST'])
@jwt_required()
@admin_required
def backup_data():
    """Create database backup"""
    try:
        backup_file = backup_database()
        
        if backup_file:
            return jsonify({
                'success': True,
                'message': 'Backup created successfully',
                'backup_file': backup_file
            }), 200
        else:
            return jsonify({
                'success': False,
                'message': 'Backup failed'
            }), 500
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Backup failed',
            'error': str(e)
        }), 500

@admin_bp.route('/system/export', methods=['POST'])
@jwt_required()
@admin_required
def export_data():
    """Export data to JSON"""
    try:
        export_to_json()
        
        return jsonify({
            'success': True,
            'message': 'Data exported successfully'
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Export failed',
            'error': str(e)
        }), 500

@admin_bp.route('/system/stats', methods=['GET'])
@jwt_required()
@admin_required
def system_stats():
    """Get system statistics"""
    try:
        import psutil
        import platform
        
        # System info
        system_info = {
            'platform': platform.platform(),
            'python_version': platform.python_version(),
            'cpu_count': psutil.cpu_count(),
            'memory_total': f"{psutil.virtual_memory().total / (1024**3):.1f} GB",
            'memory_used': f"{psutil.virtual_memory().used / (1024**3):.1f} GB",
            'disk_total': f"{psutil.disk_usage('/').total / (1024**3):.1f} GB",
            'disk_used': f"{psutil.disk_usage('/').used / (1024**3):.1f} GB"
        }
        
        # Database size
        import os
        db_size = os.path.getsize('instance/portal.db') if os.path.exists('instance/portal.db') else 0
        system_info['database_size'] = f"{db_size / (1024**2):.2f} MB"
        
        return jsonify({
            'success': True,
            'system_info': system_info
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Failed to fetch system stats',
            'error': str(e)
        }), 500