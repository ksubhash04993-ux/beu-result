from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app import db
from models.user import User
from models.result import Result
from models.notice import Notice
from utils.auth_utils import student_required, generate_student_stats

student_bp = Blueprint('student', __name__)

@student_bp.route('/dashboard', methods=['GET'])
@jwt_required()
@student_required
def dashboard():
    """Get student dashboard data"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        if not user:
            return jsonify({
                'success': False,
                'message': 'User not found'
            }), 404
        
        # Get dashboard stats
        stats = generate_student_stats(user_id)
        
        # Get recent notices
        recent_notices = Notice.query.filter_by(is_published=True)\
            .order_by(Notice.publish_date.desc())\
            .limit(5)\
            .all()
        
        # Get current semester results
        current_results = Result.query.filter_by(
            student_id=user_id,
            semester=user.semester
        ).all()
        
        # Get upcoming exams (simulated)
        from datetime import datetime, timedelta
        upcoming_exams = [
            {
                'subject': 'Data Structures',
                'date': (datetime.utcnow() + timedelta(days=15)).strftime('%Y-%m-%d'),
                'venue': 'Hall A'
            },
            {
                'subject': 'Database Management',
                'date': (datetime.utcnow() + timedelta(days=18)).strftime('%Y-%m-%d'),
                'venue': 'Hall B'
            }
        ]
        
        return jsonify({
            'success': True,
            'user': user.to_dict(),
            'stats': stats,
            'recent_notices': [notice.to_dict() for notice in recent_notices],
            'current_results': [result.to_dict() for result in current_results],
            'upcoming_exams': upcoming_exams,
            'current_semester_subjects': [
                {'code': 'CSE301', 'name': 'Data Structures', 'teacher': 'Dr. R. Kumar'},
                {'code': 'CSE302', 'name': 'Database Management', 'teacher': 'Dr. S. Singh'},
                {'code': 'CSE303', 'name': 'Operating Systems', 'teacher': 'Prof. A. Sharma'}
            ]
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Failed to fetch dashboard data',
            'error': str(e)
        }), 500

@student_bp.route('/results', methods=['GET'])
@jwt_required()
@student_required
def get_results():
    """Get all results for student"""
    try:
        user_id = get_jwt_identity()
        
        # Get semester filter
        semester = request.args.get('semester')
        
        # Build query
        query = Result.query.filter_by(student_id=user_id)
        
        if semester:
            query = query.filter_by(semester=semester)
        
        results = query.order_by(Result.semester.desc()).all()
        
        # Group by semester
        grouped_results = {}
        for result in results:
            semester_key = f"Semester {result.semester}"
            if semester_key not in grouped_results:
                grouped_results[semester_key] = {
                    'semester': result.semester,
                    'exam_type': result.exam_type,
                    'exam_year': result.exam_year,
                    'sgpa': result.sgpa,
                    'percentage': result.percentage,
                    'result_status': result.result_status,
                    'subjects': []
                }
            grouped_results[semester_key]['subjects'].append(result.to_dict())
        
        return jsonify({
            'success': True,
            'results': list(grouped_results.values())
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Failed to fetch results',
            'error': str(e)
        }), 500

@student_bp.route('/results/<int:semester>', methods=['GET'])
@jwt_required()
@student_required
def get_semester_results(semester):
    """Get results for specific semester"""
    try:
        user_id = get_jwt_identity()
        
        results = Result.query.filter_by(
            student_id=user_id,
            semester=str(semester)
        ).order_by(Result.subject_code).all()
        
        if not results:
            return jsonify({
                'success': False,
                'message': f'No results found for semester {semester}'
            }), 404
        
        # Calculate summary
        total_subjects = len(results)
        passed_subjects = len([r for r in results if r.status == 'PASS'])
        
        return jsonify({
            'success': True,
            'semester': semester,
            'summary': {
                'total_subjects': total_subjects,
                'passed_subjects': passed_subjects,
                'failed_subjects': total_subjects - passed_subjects,
                'sgpa': results[0].sgpa if results else None,
                'percentage': results[0].percentage if results else None,
                'result_status': results[0].result_status if results else None
            },
            'subjects': [result.to_dict() for result in results]
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Failed to fetch semester results',
            'error': str(e)
        }), 500

@student_bp.route('/notices', methods=['GET'])
@jwt_required()
@student_required
def get_notices():
    """Get all notices for student"""
    try:
        user_id = get_jwt_identity()
        user = User.query.get(user_id)
        
        # Get filters
        category = request.args.get('category')
        priority = request.args.get('priority')
        limit = request.args.get('limit', 20, type=int)
        
        # Build query
        query = Notice.query.filter_by(is_published=True)
        
        if category and category != 'all':
            query = query.filter_by(category=category)
        
        if priority and priority != 'all':
            query = query.filter_by(priority=priority)
        
        # Filter by branch/semester if specified
        query = query.filter(
            (Notice.target_branch == None) | (Notice.target_branch == user.branch)
        )
        
        query = query.filter(
            (Notice.target_semester == None) | (Notice.target_semester == user.semester)
        )
        
        # Execute query
        notices = query.order_by(Notice.publish_date.desc()).limit(limit).all()
        
        return jsonify({
            'success': True,
            'notices': [notice.to_dict() for notice in notices],
            'total': len(notices)
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Failed to fetch notices',
            'error': str(e)
        }), 500

@student_bp.route('/notices/<int:notice_id>', methods=['GET'])
@jwt_required()
@student_required
def get_notice(notice_id):
    """Get specific notice and mark as read"""
    try:
        notice = Notice.query.get(notice_id)
        
        if not notice or not notice.is_published:
            return jsonify({
                'success': False,
                'message': 'Notice not found'
            }), 404
        
        # Increment view count
        notice.increment_view()
        
        return jsonify({
            'success': True,
            'notice': notice.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Failed to fetch notice',
            'error': str(e)
        }), 500

@student_bp.route('/notices/<int:notice_id>/read', methods=['POST'])
@jwt_required()
@student_required
def mark_notice_read(notice_id):
    """Mark notice as read for student"""
    try:
        notice = Notice.query.get(notice_id)
        
        if not notice:
            return jsonify({
                'success': False,
                'message': 'Notice not found'
            }), 404
        
        # In a real app, you'd have a separate table for user_notice_read
        # For now, we'll just update the notice
        notice.is_read = True
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Notice marked as read'
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': 'Failed to mark notice as read',
            'error': str(e)
        }), 500

@student_bp.route('/attendance', methods=['GET'])
@jwt_required()
@student_required
def get_attendance():
    """Get student attendance (sample data)"""
    try:
        user_id = get_jwt_identity()
        
        # Sample attendance data
        attendance_data = {
            'overall_percentage': 85.5,
            'subjects': [
                {
                    'subject': 'Data Structures',
                    'code': 'CSE301',
                    'attended': 42,
                    'total': 48,
                    'percentage': 87.5,
                    'status': 'Good'
                },
                {
                    'subject': 'Database Management',
                    'code': 'CSE302',
                    'attended': 40,
                    'total': 48,
                    'percentage': 83.3,
                    'status': 'Good'
                },
                {
                    'subject': 'Operating Systems',
                    'code': 'CSE303',
                    'attended': 38,
                    'total': 48,
                    'percentage': 79.2,
                    'status': 'Satisfactory'
                }
            ]
        }
        
        return jsonify({
            'success': True,
            'attendance': attendance_data
        }), 200
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': 'Failed to fetch attendance',
            'error': str(e)
        }), 500