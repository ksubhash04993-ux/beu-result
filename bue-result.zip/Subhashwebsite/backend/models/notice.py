from app import db
from datetime import datetime

class Notice(db.Model):
    """Notice/Announcement model"""
    __tablename__ = 'notices'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50), default='general')  # exam, academic, event, urgent
    priority = db.Column(db.String(20), default='normal')  # normal, urgent
    
    # Author info
    author = db.Column(db.String(100))
    author_role = db.Column(db.String(50))
    
    # Dates
    publish_date = db.Column(db.DateTime, default=datetime.utcnow)
    valid_until = db.Column(db.DateTime)
    
    # Files/Attachments
    attachment_url = db.Column(db.String(500))
    attachment_name = db.Column(db.String(200))
    
    # Target audience
    target_branch = db.Column(db.String(50))  # Null means all branches
    target_semester = db.Column(db.String(10))  # Null means all semesters
    
    # Status
    is_published = db.Column(db.Boolean, default=True)
    is_read = db.Column(db.Boolean, default=False)  # For individual users
    
    # Stats
    view_count = db.Column(db.Integer, default=0)
    
    def increment_view(self):
        """Increment view count"""
        self.view_count += 1
        db.session.commit()
    
    def to_dict(self):
        """Convert notice object to dictionary"""
        return {
            'id': self.id,
            'title': self.title,
            'content': self.content,
            'category': self.category,
            'priority': self.priority,
            'author': self.author,
            'author_role': self.author_role,
            'publish_date': self.publish_date.isoformat() if self.publish_date else None,
            'valid_until': self.valid_until.isoformat() if self.valid_until else None,
            'attachment_url': self.attachment_url,
            'attachment_name': self.attachment_name,
            'target_branch': self.target_branch,
            'target_semester': self.target_semester,
            'is_published': self.is_published,
            'view_count': self.view_count,
            'formatted_date': self.publish_date.strftime('%d %b %Y') if self.publish_date else None
        }
    
    def __repr__(self):
        return f'<Notice {self.id} - {self.title}>'