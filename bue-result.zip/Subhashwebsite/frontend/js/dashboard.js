// Dashboard JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    const user = localStorage.getItem('studentUser');
    
    if (!user) {
        alert('Please login first');
        window.location.href = '../login.html';
        return;
    }
    
    const userData = JSON.parse(user);
    
    // Update user info
    document.getElementById('studentName').textContent = userData.name || 'Student';
    document.getElementById('studentRoll').textContent = `Roll No: ${userData.rollno || 'N/A'}`;
    document.getElementById('welcomeMsg').textContent = `Welcome back, ${userData.name?.split(' ')[0] || 'Student'}!`;
    
    // Update current time
    function updateTime() {
        const now = new Date();
        const timeStr = now.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit',
            hour12: true 
        });
        const dateStr = now.toLocaleDateString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        document.getElementById('currentTime').textContent = `${dateStr} | ${timeStr}`;
    }
    
    updateTime();
    setInterval(updateTime, 60000); // Update every minute
    
    // Logout functionality
    document.getElementById('logoutBtn').addEventListener('click', function(e) {
        e.preventDefault();
        if (confirm('Are you sure you want to logout?')) {
            localStorage.removeItem('studentUser');
            window.location.href = '../login.html';
        }
    });
    
    // Mobile menu toggle (if needed)
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });
    }
    
    // Load student stats (from localStorage)
    loadStudentStats();
});

function loadStudentStats() {
    // This can be expanded with real data
    const stats = {
        percentage: '78.5%',
        notesDownloaded: '24',
        videosWatched: '15',
        upcomingExams: '3'
    };
    
    // Update stats cards if they exist
    const statCards = document.querySelectorAll('.stat-value');
    if (statCards.length >= 4) {
        statCards[0].textContent = stats.percentage;
        statCards[1].textContent = stats.notesDownloaded + ' Files';
        statCards[2].textContent = stats.videosWatched + ' Hours';
        statCards[3].textContent = stats.upcomingExams + ' Exams';
    }
}

// Simulate API calls for dashboard data
function fetchDashboardData() {
    // In future, replace with real API calls
    return {
        recentActivity: [
            { action: 'Checked 4th semester result', time: '2 hours ago', icon: 'check-circle', type: 'success' },
            { action: 'Downloaded DBMS notes (Unit 3)', time: '1 day ago', icon: 'download', type: 'info' },
            { action: 'Upcoming exam: Data Structures (15 June)', time: '2 days ago', icon: 'exclamation-triangle', type: 'warning' },
            { action: 'Watched OS video lecture', time: '3 days ago', icon: 'video', type: 'primary' }
        ],
        subjects: [
            { name: 'Data Structures', code: 'CSE301', teacher: 'Dr. R. Kumar', schedule: 'Mon, Wed, Fri' },
            { name: 'Database Management', code: 'CSE302', teacher: 'Dr. S. Singh', schedule: 'Tue, Thu' },
            { name: 'Operating Systems', code: 'CSE303', teacher: 'Prof. A. Sharma', schedule: 'Mon, Wed' },
            { name: 'Computer Networks', code: 'CSE304', teacher: 'Dr. P. Verma', schedule: 'Tue, Fri' }
        ]
    };
}